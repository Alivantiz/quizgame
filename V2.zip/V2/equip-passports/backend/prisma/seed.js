import { PrismaClient, Role } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  // 🔹 Админ (с уникальным ID)
  await prisma.user.create({
    data: {
      authId: "010203",
      fio: "Администратор",
      position: "Инженер связи",
      role: Role.admin,
    },
  }).catch(() => console.log("ℹ️ Admin уже есть"));

  // 🔹 Департаменты
  await prisma.department.create({ data: { name: "АСУТП" } }).catch(() => {});
  await prisma.department.create({ data: { name: "СГЭ" } }).catch(() => {});
  await prisma.department.create({ data: { name: "СГМ" } }).catch(() => {});
  console.log("✅ Departments ok");

  // 🔹 Участки
  await prisma.area.create({ data: { name: "ГТП" } }).catch(() => {});
  await prisma.area.create({ data: { name: "ЦППР" } }).catch(() => {});
  await prisma.area.create({ data: { name: "АЦ" } }).catch(() => {});
  await prisma.area.create({ data: { name: "ТНС" } }).catch(() => {});
  console.log("✅ Areas ok");

  // 🔹 Примеры пользователей
  await prisma.user.create({
    data: {
      authId: "U-GTP-001",
      fio: "Иванов Иван (ГТП)",
      role: Role.uchastok,
      area: { connect: { name: "ГТП" } },   // привязка к цеху
    },
  }).catch(() => {});

  await prisma.user.create({
    data: {
      authId: "S-ASUTP-001",
      fio: "Петров Петр (АСУТП)",
      role: Role.sluzhba,
      department: { connect: { name: "АСУТП" } }, // привязка к службе
    },
  }).catch(() => {});

  // 🔹 Гость (только просмотр)
  await prisma.user.create({
    data: {
      authId: "GUEST-001",
      fio: "Гость",
      role: Role.guest,
    },
  }).catch(() => {});

  console.log("✅ Users ok");
}

main()
  .catch((e) => {
    console.error("❌ Seed error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
