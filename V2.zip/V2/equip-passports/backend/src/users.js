import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { authGuard } from "./middleware.js";

const prisma = new PrismaClient();
const router = Router();

// 🔹 утилита для приведения юзера к единому виду
function mapUser(u) {
  let belongsTo = null;
  let areaId = null;
  let departmentId = null;

  if (u.area) {
    belongsTo = { type: "area", id: u.area.id, name: u.area.name };
    areaId = u.area.id;
  } else if (u.department) {
    belongsTo = { type: "department", id: u.department.id, name: u.department.name };
    departmentId = u.department.id;
  }

  return {
    id: u.id,
    authId: u.authId,
    fio: u.fio,
    position: u.position,
    role: u.role?.toLowerCase().trim(),
    belongsTo,
    areaId,
    departmentId,
  };
}

// -----------------------------------------------------------------------------
// 📌 Текущий пользователь
// -----------------------------------------------------------------------------
router.get("/me", authGuard, async (req, res) => {
  try {
    if (req.user.role === "guest") {
      return res.json({ role: "guest" });
    }

    const me = await prisma.user.findUnique({
      where: { id: req.user.id },
      include: { department: true, area: true },
    });
    if (!me) return res.status(404).json({ error: "User not found" });

    return res.json(mapUser(me));
  } catch (e) {
    console.error("Error in /me:", e);
    return res.status(500).json({ error: "Internal error", details: String(e) });
  }
});

router.put("/me", authGuard, async (req, res) => {
  if (req.user.role === "guest") {
    return res.status(403).json({ error: "Guests cannot update profile" });
  }
  try {
    const { fio, position } = req.body || {};
    const updated = await prisma.user.update({
      where: { id: req.user.id },
      data: { fio, position },
      include: { area: true, department: true },
    });
    return res.json(mapUser(updated));
  } catch (e) {
    return res.status(400).json({ error: "Cannot update profile", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Пользователи (список + поиск по ФИО)
// -----------------------------------------------------------------------------
router.get("/", authGuard, async (req, res) => {
  // доступ только admin и sluzhba
  if (!["admin", "sluzhba"].includes(req.user.role)) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const { areaId, departmentId, q } = req.query;
  const where = {};

  if (areaId) where.areaId = Number(areaId);
  if (departmentId) where.departmentId = Number(departmentId);

  // 🔎 поиск по ФИО (минимум 3 буквы)
  if (q && q.length >= 3) {
    where.fio = { contains: q, mode: "insensitive" };
  }

  try {
    const users = await prisma.user.findMany({
      where,
      include: { department: true, area: true },
      orderBy: { fio: "asc" },
      take: 50, // ограничим результат (например, максимум 50 совпадений)
    });

    return res.json(users.map(mapUser));
  } catch (e) {
    console.error("Error in /users:", e);
    return res.status(500).json({ error: "Internal error", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Создание пользователя
// -----------------------------------------------------------------------------
router.post("/", authGuard, async (req, res) => {
  if (req.user.role !== "admin")
    return res.status(403).json({ error: "Forbidden" });

  let { authId, fio, position, role, departmentId, areaId } = req.body || {};
  if (!authId) return res.status(400).json({ error: "authId is required" });

  if (departmentId) {
    areaId = null;
  } else if (areaId) {
    departmentId = null;
  }

  try {
    const user = await prisma.user.create({
      data: { authId, fio, position, role, departmentId, areaId },
      include: { department: true, area: true },
    });
    return res.status(201).json(mapUser(user));
  } catch (e) {
    return res.status(400).json({ error: "Cannot create user", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Обновление пользователя
// -----------------------------------------------------------------------------
router.put("/:id", authGuard, async (req, res) => {
  if (req.user.role !== "admin")
    return res.status(403).json({ error: "Forbidden" });

  const id = Number(req.params.id);
  if (Number.isNaN(id)) return res.status(400).json({ error: "Bad user id" });

  let { fio, position, role, departmentId, areaId } = req.body || {};

  if (departmentId) {
    areaId = null;
  } else if (areaId) {
    departmentId = null;
  }

  try {
    const user = await prisma.user.update({
      where: { id },
      data: { fio, position, role, departmentId, areaId },
      include: { department: true, area: true },
    });
    return res.json(mapUser(user));
  } catch (e) {
    return res.status(400).json({ error: "Cannot update user", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Удаление пользователя
// -----------------------------------------------------------------------------
router.delete("/:id", authGuard, async (req, res) => {
  if (req.user.role !== "admin")
    return res.status(403).json({ error: "Forbidden" });

  const id = Number(req.params.id);
  if (Number.isNaN(id)) return res.status(400).json({ error: "Bad user id" });

  try {
    await prisma.user.delete({ where: { id } });
    return res.json({ ok: true });
  } catch (e) {
    return res.status(400).json({ error: "Cannot delete user", details: String(e) });
  }
});

export default router;
