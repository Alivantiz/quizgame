import { Server } from "socket.io";
import { PrismaClient } from "@prisma/client";
import { materializeWorkOrder } from "./enums.js";

const prisma = new PrismaClient();
let io;

export function initWs(httpServer) {
  io = new Server(httpServer, {
    cors: { origin: "*" }, // ⚠️ лучше ограничить фронтовыми доменами
  });

  io.on("connection", (socket) => {
    console.log("🔌 user connected", socket.id);

    socket.on("joinAdmin", () => {
      socket.join("admins");
      console.log("🟦", socket.id, "joined admins");
    });

    socket.on("joinDepartment", (depId) => {
      if (depId) {
        socket.join(`dep_${depId}`);
        console.log("🟩", socket.id, "joined dep:", depId);
      }
    });

    socket.on("joinUser", (userId) => {
      if (userId) {
        socket.join(`user_${userId}`);
        console.log("🟨", socket.id, "joined user:", userId);
      }
    });

    socket.on("markRead", async ({ userId }) => {
      if (!userId) return;
      await prisma.unreadWorkOrder.deleteMany({ where: { userId } });
      io.to(`user_${userId}`).emit("unreadCount", { count: 0 });
      console.log("✉️ unread cleared for user:", userId);
    });

    socket.on("disconnect", () => {
      console.log("🔌 disconnected", socket.id);
    });
  });
}

// -----------------------------------------------------------------------------
// 🔹 Общая рассылка по департаментам и юзерам
// -----------------------------------------------------------------------------
async function emitForDeps(event, order, excludeUserId = null) {
  const deps = Array.isArray(order.assignments)
    ? order.assignments.map((a) => a.department).filter(Boolean)
    : [];

  for (const dep of deps) {
    io.to(`dep_${dep.id}`).emit(event, order);

    const users = await prisma.user.findMany({
      where: {
        departmentId: dep.id,
        id: excludeUserId ? { not: excludeUserId } : undefined,
      },
      select: { id: true },
    });

    for (const u of users) {
      io.to(`user_${u.id}`).emit(event, order);

      if (event === "newWorkOrder") {
        try {
          await prisma.unreadWorkOrder.create({
            data: { userId: u.id, orderId: order.id },
          });
        } catch {
          // дубликат — ок
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// 📢 Универсальное обновление (видят все, включая guest/viewer)
// -----------------------------------------------------------------------------
export function notifyOrderUpdated(order) {
  const mat = materializeWorkOrder(order);
  io.emit("orderUpdated", mat);
  console.log("📣 orderUpdated ->", mat.id, mat.status);
}

// -----------------------------------------------------------------------------
// 🆕 Новая заявка
// -----------------------------------------------------------------------------
export async function notifyNewWorkOrder(order, excludeUserId = null) {
  const mat = materializeWorkOrder(order);

  io.to("admins").emit("newWorkOrder", mat);
  await emitForDeps("newWorkOrder", mat, excludeUserId);

  notifyOrderUpdated(order);
}

// -----------------------------------------------------------------------------
// 🔄 Статус изменился
// -----------------------------------------------------------------------------
export async function notifyStatusChanged(order, excludeUserId = null) {
  const mat = materializeWorkOrder(order);

  io.to("admins").emit("statusChanged", mat);
  await emitForDeps("statusChanged", mat, excludeUserId);

  notifyOrderUpdated(order);
}

// -----------------------------------------------------------------------------
// 💬 Комментарий
// -----------------------------------------------------------------------------
export function notifyCommentAdded(orderId, comment) {
  io.emit("commentAdded", { orderId, comment });
  prisma.workOrder.findUnique({
    where: { id: orderId },
    include: {
      equipment: true,
      area: true,
      assignments: { include: { department: true } },
      attachments: true,
      issuedBy: true,
      acceptedBy: true,
      completedBy: true,
      comments: { include: { author: true }, orderBy: { createdAt: "asc" } },
    },
  }).then((order) => {
    if (order) notifyOrderUpdated(order);
  });
}

// -----------------------------------------------------------------------------
// 📎 Вложение
// -----------------------------------------------------------------------------
export function notifyAttachmentAdded(orderId, attachment) {
  io.emit("attachmentAdded", { orderId, attachment });
  prisma.workOrder.findUnique({
    where: { id: orderId },
    include: {
      equipment: true,
      area: true,
      assignments: { include: { department: true } },
      attachments: true,
      issuedBy: true,
      acceptedBy: true,
      completedBy: true,
      comments: { include: { author: true }, orderBy: { createdAt: "asc" } },
    },
  }).then((order) => {
    if (order) notifyOrderUpdated(order);
  });
}
