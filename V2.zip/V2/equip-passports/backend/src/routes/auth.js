// backend/src/routes/auth.js
import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import jwt from "jsonwebtoken";

const prisma = new PrismaClient();
const router = Router();

const JWT_SECRET = process.env.JWT_SECRET || "dev";

// анти-кэш
function noStore(res) {
  res.set("Cache-Control", "no-store");
  res.set("Vary", "Cookie,Authorization");
}

// базовые опции для кук
const baseCookieOpts = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production", // ⚠️ в проде только HTTPS
  sameSite: "lax",
  path: "/",
};

// установить access+refresh
function setAuthCookies(res, access, refresh) {
  res.cookie("access", access, { ...baseCookieOpts, maxAge: 15 * 60 * 1000 });
  res.cookie("refresh", refresh, {
    ...baseCookieOpts,
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
}

// --- LOGIN ---
router.post("/login", async (req, res) => {
  noStore(res);
  try {
    const { authId } = req.body || {};
    if (!authId) return res.status(400).json({ error: "authId required" });

    const user = await prisma.user.findUnique({
      where: { authId },
      include: { area: true, department: true },
    });
    if (!user) return res.status(401).json({ error: "bad authId" });

    const role = user.role?.toLowerCase().trim();

    const access = jwt.sign(
      {
        id: user.id,
        authId: user.authId,
        role,
        areaId: user.areaId,
        departmentId: user.departmentId,
      },
      JWT_SECRET,
      { expiresIn: "15m" }
    );

    const refresh = jwt.sign(
      { id: user.id, authId: user.authId },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    await prisma.refreshToken.create({
      data: {
        token: refresh,
        userId: user.id,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    }).catch(() => {});

    setAuthCookies(res, access, refresh);

    res.json({
      user: {
        id: user.id,
        authId: user.authId,
        fio: user.fio,
        position: user.position,
        role,
        areaId: user.areaId,
        areaName: user.area?.name || null,
        departmentId: user.departmentId,
        departmentName: user.department?.name || null,
      },
      access,
    });
  } catch (e) {
    console.error("login error:", e);
    res.status(500).json({ error: "internal" });
  }
});

// --- REFRESH ---
router.post("/refresh", async (req, res) => {
  noStore(res);
  try {
    const refresh = req.cookies?.refresh;
    if (!refresh) return res.status(400).json({ error: "no refresh token" });

    const rt = await prisma.refreshToken.findUnique({
      where: { token: refresh },
      include: { user: { include: { area: true, department: true } } },
    });
    if (!rt || rt.expiresAt < new Date())
      return res.status(401).json({ error: "invalid refresh token" });

    let payload;
    try {
      payload = jwt.verify(refresh, JWT_SECRET);
    } catch {
      return res.status(401).json({ error: "invalid refresh token" });
    }

    const user = await prisma.user.findUnique({
      where: { id: payload.id },
      include: { area: true, department: true },
    });
    if (!user) return res.status(401).json({ error: "user not found" });

    const role = user.role?.toLowerCase().trim();

    const access = jwt.sign(
      {
        id: user.id,
        authId: user.authId,
        role,
        areaId: user.areaId,
        departmentId: user.departmentId,
      },
      JWT_SECRET,
      { expiresIn: "15m" }
    );

    res.cookie("access", access, { ...baseCookieOpts, maxAge: 15 * 60 * 1000 });

    res.json({
      ok: true,
      access,
      user: {
        id: user.id,
        authId: user.authId,
        fio: user.fio,
        position: user.position,
        role,
        areaId: user.areaId,
        areaName: user.area?.name || null,
        departmentId: user.departmentId,
        departmentName: user.department?.name || null,
      },
    });
  } catch (e) {
    console.error("refresh error:", e);
    res.status(500).json({ error: "internal" });
  }
});

// --- LOGOUT ---
router.post("/logout", async (req, res) => {
  noStore(res);
  try {
    const refresh = req.cookies?.refresh;
    if (refresh) {
      await prisma.refreshToken.deleteMany({ where: { token: refresh } }).catch(() => {});
    }
    res.clearCookie("access", baseCookieOpts);
    res.clearCookie("refresh", baseCookieOpts);
    res.json({ ok: true });
  } catch (e) {
    console.error("logout error:", e);
    res.status(500).json({ error: "internal" });
  }
});

export default router;
