import { Router } from "express";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const router = Router();

/**
 * 📊 Общая статистика + гибкие фильтры
 * - Доступно всем (гости тоже)
 * - query-параметры:
 *   - areaId        → фильтр по цеху
 *   - departmentId  → фильтр по подразделению
 *   - status        → фильтр по статусу заявки
 *   - from / to     → фильтр по дате создания заявки
 */
router.get("/", async (req, res) => {
  try {
    const { areaId, departmentId, status, from, to } = req.query;

    // фильтр для заявок
    const orderWhere = {};
    if (areaId) orderWhere.areaId = Number(areaId);
    if (status) orderWhere.status = status.toString().toUpperCase();
    if (from || to) {
      orderWhere.createdAt = {};
      if (from) orderWhere.createdAt.gte = new Date(from);
      if (to) orderWhere.createdAt.lte = new Date(to);
    }
    if (departmentId) {
      orderWhere.assignments = { some: { departmentId: Number(departmentId) } };
    }

    // фильтр для оборудования
    const equipWhere = {};
    if (areaId) equipWhere.areaId = Number(areaId);

    // заявки
    const totalOrders = await prisma.workOrder.count({ where: orderWhere });
    const newOrders = await prisma.workOrder.count({
      where: { ...orderWhere, status: "NOVAYA" },
    });
    const inProgressOrders = await prisma.workOrder.count({
      where: { ...orderWhere, status: "V_RABOTE" },
    });
    const completedOrders = await prisma.workOrder.count({
      where: { ...orderWhere, status: "ZAVERSHENA" },
    });

    // оборудование
    const totalEquip = await prisma.equipment.count({ where: equipWhere });
    const workingEquip = await prisma.equipment.count({
      where: { ...equipWhere, status: "RABOTAET" },
    });
    const repairEquip = await prisma.equipment.count({
      where: { ...equipWhere, status: "AVARIYA" },
    });
    const reserveEquip = await prisma.equipment.count({
      where: { ...equipWhere, status: "V_REZERVE" },
    });

    res.json({
      filters: { areaId, departmentId, status, from, to }, // 👈 для отладки
      workOrders: {
        total: totalOrders,
        new: newOrders,
        inProgress: inProgressOrders,
        completed: completedOrders,
      },
      equipment: {
        total: totalEquip,
        working: workingEquip,
        repair: repairEquip,
        reserve: reserveEquip,
      },
    });
  } catch (e) {
    console.error("Ошибка dashboard:", e);
    res.status(500).json({ error: "Ошибка получения статистики", details: String(e) });
  }
});

export default router;
