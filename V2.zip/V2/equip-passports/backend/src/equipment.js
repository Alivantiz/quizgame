// backend/src/equipment.js
import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { authGuard } from "./middleware.js";
import {
  toEnumEquipStatus,
  materializeEquipment,
  materializeWorkOrder,
} from "./enums.js";

const prisma = new PrismaClient();
const router = Router();

/**
 * 🔹 Проверка доступа к оборудованию (просмотр)
 */
function canAccessEquipment(user, equipment) {
  if (!user || user.role === "guest") return true; // гость тоже видит
  if (user.role === "admin") return true;
  if (user.role === "uchastok" && equipment.areaId === user.areaId) return true;
  if (user.role === "sluzhba") return true;
  if (user.role === "viewer") return true;
  return false;
}

/**
 * 🔹 Проверка права на изменение оборудования
 */
function canManageEquipment(user, equipment) {
  if (!user || user.role === "guest") return false;
  if (user.role === "admin") return true;
  if (user.role === "uchastok" && equipment.areaId === user.areaId) return true;
  return false; // служба и viewer/guest не могут менять
}

// -----------------------------------------------------------------------------
// 📌 Характеристики оборудования
// -----------------------------------------------------------------------------
router.get("/:id/attributes", authGuard, async (req, res) => {
  try {
    const eq = await prisma.equipment.findUnique({ where: { id: Number(req.params.id) } });
    if (!eq || !canAccessEquipment(req.user, eq)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    const attrs = await prisma.equipmentAttribute.findMany({
      where: { equipmentId: eq.id },
      orderBy: { id: "asc" },
    });
    res.json(attrs);
  } catch (e) {
    res.status(500).json({ error: "Ошибка получения характеристик", details: String(e) });
  }
});

router.post("/:id/attributes", authGuard, async (req, res) => {
  const { key, value } = req.body || {};
  if (!key) return res.status(400).json({ error: "key обязателен" });

  try {
    const eq = await prisma.equipment.findUnique({ where: { id: Number(req.params.id) } });
    if (!eq || !canManageEquipment(req.user, eq)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    const attr = await prisma.equipmentAttribute.create({
      data: { equipmentId: eq.id, key, value: value || "" },
    });
    res.status(201).json(attr);
  } catch (e) {
    res.status(500).json({ error: "Ошибка добавления характеристики", details: String(e) });
  }
});

router.put("/attributes/:attrId", authGuard, async (req, res) => {
  const { key, value } = req.body || {};
  try {
    const attr = await prisma.equipmentAttribute.findUnique({
      where: { id: Number(req.params.attrId) },
      include: { equipment: true },
    });
    if (!attr || !canManageEquipment(req.user, attr.equipment)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    const updated = await prisma.equipmentAttribute.update({
      where: { id: attr.id },
      data: { key, value },
    });
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: "Ошибка обновления характеристики", details: String(e) });
  }
});

router.delete("/attributes/:attrId", authGuard, async (req, res) => {
  try {
    const attr = await prisma.equipmentAttribute.findUnique({
      where: { id: Number(req.params.attrId) },
      include: { equipment: true },
    });
    if (!attr || !canManageEquipment(req.user, attr.equipment)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    await prisma.equipmentAttribute.delete({ where: { id: attr.id } });
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: "Ошибка удаления характеристики", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Документы оборудования
// -----------------------------------------------------------------------------
router.get("/:id/documents", authGuard, async (req, res) => {
  try {
    const eq = await prisma.equipment.findUnique({ where: { id: Number(req.params.id) } });
    if (!eq || !canAccessEquipment(req.user, eq)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    const docs = await prisma.equipmentDocument.findMany({
      where: { equipmentId: eq.id },
      orderBy: { createdAt: "desc" },
    });
    res.json(docs);
  } catch (e) {
    res.status(500).json({ error: "Ошибка получения документов", details: String(e) });
  }
});

router.post("/:id/documents", authGuard, async (req, res) => {
  const { name, url } = req.body || {};
  if (!name || !url) return res.status(400).json({ error: "name и url обязательны" });

  try {
    const eq = await prisma.equipment.findUnique({ where: { id: Number(req.params.id) } });
    if (!eq || !canManageEquipment(req.user, eq)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    const doc = await prisma.equipmentDocument.create({
      data: { equipmentId: eq.id, name, url },
    });
    res.status(201).json(doc);
  } catch (e) {
    res.status(400).json({ error: "Ошибка добавления документа", details: String(e) });
  }
});

router.delete("/documents/:docId", authGuard, async (req, res) => {
  try {
    const doc = await prisma.equipmentDocument.findUnique({
      where: { id: Number(req.params.docId) },
      include: { equipment: true },
    });
    if (!doc || !canManageEquipment(req.user, doc.equipment)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    await prisma.equipmentDocument.delete({ where: { id: doc.id } });
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: "Ошибка удаления документа", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Заявки по оборудованию
// -----------------------------------------------------------------------------
router.get("/:id/orders", authGuard, async (req, res) => {
  try {
    const eq = await prisma.equipment.findUnique({ where: { id: Number(req.params.id) } });
    if (!eq || !canAccessEquipment(req.user, eq)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    const orders = await prisma.workOrder.findMany({
      where: { equipmentId: eq.id },
      orderBy: { createdAt: "desc" },
      include: {
        assignments: { include: { department: true } },
        equipment: { include: { area: true } },
        area: true,
        attachments: true,
        comments: { include: { author: true } },
      },
    });
    res.json(orders.map(materializeWorkOrder));
  } catch (e) {
    res.status(500).json({ error: "Ошибка получения заявок", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Получить одно оборудование
// -----------------------------------------------------------------------------
router.get("/:id", authGuard, async (req, res) => {
  const id = Number(req.params.id);
  try {
    const eq = await prisma.equipment.findUnique({ where: { id }, include: { area: true } });
    if (!eq || !canAccessEquipment(req.user, eq)) {
      return res.status(403).json({ error: "нет доступа" });
    }
    res.json(materializeEquipment(eq));
  } catch (e) {
    res.status(500).json({ error: "Ошибка загрузки оборудования", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Список оборудования
// -----------------------------------------------------------------------------
router.get("/", authGuard, async (req, res) => {
  const { status, areaId } = req.query;
  const where = {};
  const statusCode = toEnumEquipStatus(status);
  if (status && statusCode) where.status = statusCode;

  if (req.user?.role === "uchastok" && req.user.areaId) {
    where.areaId = req.user.areaId;
  } else if (areaId) {
    where.areaId = Number(areaId);
  }

  try {
    const list = await prisma.equipment.findMany({
      where,
      orderBy: { id: "desc" },
      include: { area: true },
    });
    res.json(list.map(materializeEquipment));
  } catch (e) {
    res.status(500).json({ error: "Ошибка загрузки оборудования", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Создать оборудование
// -----------------------------------------------------------------------------
router.post("/", authGuard, async (req, res) => {
  let { category, position, name, serial, areaId, status } = req.body || {};
  if (!name || !serial) return res.status(400).json({ error: "name и serial обязательны" });

  if (req.user.role === "sluzhba" || req.user.role === "viewer" || req.user.role === "guest") {
    return res.status(403).json({ error: "нет прав на создание оборудования" });
  }

  if (req.user.role === "uchastok") {
    areaId = req.user.areaId;
  }

  if (!areaId) return res.status(400).json({ error: "areaId обязателен" });

  try {
    const item = await prisma.equipment.create({
      data: {
        category,
        position,
        name,
        serial,
        areaId: Number(areaId),
        status: toEnumEquipStatus(status) || "RABOTAET",
      },
      include: { area: true },
    });
    res.status(201).json(materializeEquipment(item));
  } catch (e) {
    res.status(400).json({ error: "Ошибка создания оборудования", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Обновить оборудование
// -----------------------------------------------------------------------------
router.put("/:id", authGuard, async (req, res) => {
  const id = Number(req.params.id);
  let { category, position, name, serial, areaId, status } = req.body || {};

  try {
    const eq = await prisma.equipment.findUnique({ where: { id } });
    if (!eq) return res.status(404).json({ error: "не найдено" });

    if (!canManageEquipment(req.user, eq)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    if (req.user.role === "uchastok") {
      areaId = req.user.areaId;
    }

    const item = await prisma.equipment.update({
      where: { id },
      data: {
        category,
        position,
        name,
        serial,
        areaId: Number(areaId),
        status: toEnumEquipStatus(status) || "RABOTAET",
      },
      include: { area: true },
    });
    res.json(materializeEquipment(item));
  } catch (e) {
    res.status(400).json({ error: "Ошибка обновления оборудования", details: String(e) });
  }
});

// -----------------------------------------------------------------------------
// 📌 Удалить оборудование
// -----------------------------------------------------------------------------
router.delete("/:id", authGuard, async (req, res) => {
  const id = Number(req.params.id);
  try {
    const eq = await prisma.equipment.findUnique({ where: { id } });
    if (!eq) return res.status(404).json({ error: "не найдено" });

    if (!canManageEquipment(req.user, eq)) {
      return res.status(403).json({ error: "нет доступа" });
    }

    await prisma.equipmentDocument.deleteMany({ where: { equipmentId: id } });
    await prisma.equipmentAttribute.deleteMany({ where: { equipmentId: id } });
    await prisma.workOrderAttachment.deleteMany({ where: { order: { equipmentId: id } } });
    await prisma.comment.deleteMany({ where: { order: { equipmentId: id } } });
    await prisma.workOrderAssignment.deleteMany({ where: { workOrder: { equipmentId: id } } });
    await prisma.workOrder.deleteMany({ where: { equipmentId: id } });
    await prisma.equipment.delete({ where: { id } });

    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: "Ошибка удаления оборудования", details: String(e) });
  }
});

export default router;
