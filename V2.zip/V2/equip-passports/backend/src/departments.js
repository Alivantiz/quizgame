import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { authGuard } from "./middleware.js";

const prisma = new PrismaClient();
const router = Router();

// -------------------------------------------------
// 📌 Список подразделений
//     🔹 Доступен всем, включая гостей
// -------------------------------------------------
router.get("/", async (_req, res) => {
  try {
    const list = await prisma.department.findMany({
      orderBy: { id: "asc" },
    });
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: "Ошибка получения подразделений", details: String(e) });
  }
});

// -------------------------------------------------
// 📌 Создать подразделение (только админ)
// -------------------------------------------------
router.post("/", authGuard, async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Нет прав для создания подразделения" });
  }
  const { name } = req.body || {};
  if (!name) return res.status(400).json({ error: "Поле 'name' обязательно" });

  try {
    const dep = await prisma.department.create({ data: { name } });
    res.status(201).json(dep);
  } catch (e) {
    res.status(400).json({ error: "Ошибка создания подразделения", details: String(e) });
  }
});

// -------------------------------------------------
// 📌 Обновить подразделение (только админ)
// -------------------------------------------------
router.put("/:id", authGuard, async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Нет прав для изменения подразделения" });
  }
  const { name } = req.body || {};
  try {
    const dep = await prisma.department.update({
      where: { id: Number(req.params.id) },
      data: { name },
    });
    res.json(dep);
  } catch (e) {
    res.status(400).json({ error: "Ошибка обновления подразделения", details: String(e) });
  }
});

// -------------------------------------------------
// 📌 Удалить подразделение (с очисткой связей, только админ)
// -------------------------------------------------
router.delete("/:id", authGuard, async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Нет прав для удаления подразделения" });
  }
  const id = Number(req.params.id);

  try {
    // отвязываем пользователей
    await prisma.user.updateMany({
      where: { departmentId: id },
      data: { departmentId: null },
    });

    // удаляем назначения заявок
    await prisma.workOrderAssignment.deleteMany({
      where: { departmentId: id },
    });

    // удаляем подразделение
    await prisma.department.delete({ where: { id } });

    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: "Ошибка удаления подразделения", details: String(e) });
  }
});

export default router;
