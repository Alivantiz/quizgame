import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { authGuard } from "./middleware.js";

const prisma = new PrismaClient();
const router = Router();

/**
 * 🔹 Список всех цехов
 * - Доступен всем, включая гостей
 */
router.get("/", async (req, res) => {
  try {
    const areas = await prisma.area.findMany({ orderBy: { id: "asc" } });
    res.json(areas);
  } catch (e) {
    res.status(500).json({ error: "Ошибка загрузки цехов", details: String(e) });
  }
});

/**
 * 🔹 Создать новый цех
 * - Только admin
 */
router.post("/", authGuard, async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Нет прав для создания цеха" });
  }

  try {
    const area = await prisma.area.create({
      data: { name: req.body.name },
    });
    res.status(201).json(area);
  } catch (e) {
    res.status(400).json({
      error: "Ошибка создания цеха (возможно, дублирование)",
      details: String(e),
    });
  }
});

/**
 * 🔹 Обновить название цеха
 * - Только admin
 */
router.put("/:id", authGuard, async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Нет прав для изменения цеха" });
  }

  try {
    const area = await prisma.area.update({
      where: { id: Number(req.params.id) },
      data: { name: req.body.name },
    });
    res.json(area);
  } catch (e) {
    res.status(400).json({ error: "Ошибка обновления цеха", details: String(e) });
  }
});

/**
 * 🔹 Удалить цех
 * - Только admin
 */
router.delete("/:id", authGuard, async (req, res) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Нет прав для удаления цеха" });
  }

  const id = Number(req.params.id);

  try {
    // отвязываем пользователей
    await prisma.user.updateMany({
      where: { areaId: id },
      data: { areaId: null },
    });

    // удаляем заявки, привязанные к этому цеху
    await prisma.workOrder.deleteMany({ where: { areaId: id } });

    // удаляем оборудование вместе с атрибутами/доками
    const eqList = await prisma.equipment.findMany({ where: { areaId: id } });
    for (const eq of eqList) {
      await prisma.equipmentDocument.deleteMany({ where: { equipmentId: eq.id } });
      await prisma.equipmentAttribute.deleteMany({ where: { equipmentId: eq.id } });
      await prisma.workOrderAttachment.deleteMany({
        where: { order: { equipmentId: eq.id } },
      });
      await prisma.comment.deleteMany({
        where: { order: { equipmentId: eq.id } },
      });
    }
    await prisma.equipment.deleteMany({ where: { areaId: id } });

    // удаляем сам цех
    await prisma.area.delete({ where: { id } });

    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: "Ошибка удаления цеха", details: String(e) });
  }
});

export default router;
