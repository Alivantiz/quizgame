import 'dotenv/config'
import express from 'express'
import morgan from 'morgan'
import http from 'http'
import cookieParser from 'cookie-parser'
import { corsMw } from './middleware.js'
import users from './users.js'
import equipment from './equipment.js'
import workorders from './workorders.js'
import departments from './departments.js'
import authRoutes from './routes/auth.js'
import areasRouter from "./areas.js"
import { initWs } from './ws.js'
import dashboard from "./dashboard.js"

const app = express()

app.set('trust proxy', 1)
app.set('etag', false)

// для всех API-запросов отключаем кеширование
app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) {
    res.set('Cache-Control', 'no-store')
    res.set('Vary', 'Cookie,Authorization')
  }
  next()
})

app.use(cookieParser())
app.use(express.json())
app.use(corsMw)
app.use(morgan('dev'))

app.use('/uploads', express.static('uploads'))

app.get('/api/health', (_req, res) => res.json({ ok: true }))

// 🔹 подключение роутов
app.use('/api/auth', authRoutes)
app.use('/api/users', users)
app.use('/api/equipment', equipment)
app.use('/api/workorders', workorders)
app.use('/api/departments', departments)
app.use('/api/areas', areasRouter)
app.use("/api/dashboard", dashboard)

const port = process.env.PORT || 8080
const server = http.createServer(app)
initWs(server)
server.listen(port, () => console.log(`API + WS on :${port}`))
