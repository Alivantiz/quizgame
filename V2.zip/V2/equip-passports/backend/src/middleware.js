import cors from "cors";
import jwt from "jsonwebtoken";

// --- CORS ---
const allowedOrigins = (
  process.env.CORS_ORIGIN ||
  "https://digitalpasses.uk,http://localhost:5173,http://192.168.88.145:5173,http://192.168.0.241:5173"
)
  .split(",")
  .map((o) => o.trim().replace(/\/$/, ""));

export const corsMw = cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true); // прямые запросы (Postman, curl)
    const norm = origin.replace(/\/$/, "");
    if (allowedOrigins.includes(norm)) {
      return callback(null, true);
    }
    console.warn("⛔ CORS blocked:", origin);
    return callback(new Error("Not allowed by CORS"));
  },
  credentials: true, // обязательно для кук
});

// --- Auth middleware ---
export function authGuard(req, res, next) {
  let token = req.cookies?.access || req.cookies?.token;

  if (!token) {
    const h = req.headers.authorization || "";
    if (h.startsWith("Bearer ")) token = h.slice(7);
  }

  // 🔹 Если токена нет → считаем пользователя гостем
  if (!token) {
    req.user = { role: "guest" };
    return next();
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || "dev");
    req.user = {
      id: payload.id,
      login: payload.login,
      role: payload.role,
      areaId: payload.areaId || null,
      departmentId: payload.departmentId || null,
    };
    next();
  } catch {
    // ❌ если токен кривой — не гость, а ошибка
    return res.status(401).json({ error: "Invalid token" });
  }
}

// --- Role middleware ---
export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: "unauthorized" });
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: "forbidden" });
    }
    next();
  };
}
