import { Router } from "express";
import { PrismaClient } from "@prisma/client";
import { authGuard } from "./middleware.js";
import { toEnumWorkStatus, materializeWorkOrder } from "./enums.js";
import {
  notifyNewWorkOrder,
  notifyStatusChanged,
  notifyCommentAdded,
  notifyAttachmentAdded,
} from "./ws.js";

import multer from "multer";
import path from "path";
import fs from "fs";

const prisma = new PrismaClient();
const router = Router();

// 📂 каталог для файлов
const uploadDir = "uploads";
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  },
});
const upload = multer({ storage });

// -----------------------------------------------------------------------------
// 📌 Список заявок
// -----------------------------------------------------------------------------
router.get("/", authGuard, async (req, res) => {
  const { status } = req.query;
  const where = {};
  const statusCode = toEnumWorkStatus(status);
  if (status && statusCode) where.status = statusCode;

  if (req.user.role === "uchastok") {
    where.areaId = req.user.areaId || -1;
  } else if (req.user.role === "sluzhba") {
    where.assignments = { some: { departmentId: req.user.departmentId || -1 } };
  }

  const list = await prisma.workOrder.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: {
      equipment: { include: { area: true } },
      area: true,
      assignments: { include: { department: true } },
      attachments: true,
      issuedBy: true,
      acceptedBy: true,
      completedBy: { include: { user: true } }, // 🔹
      comments: { include: { author: true }, orderBy: { createdAt: "asc" } },
    },
  });

  res.json(list.map(materializeWorkOrder));
});

// -----------------------------------------------------------------------------
// 📌 Создать заявку
// -----------------------------------------------------------------------------
router.post("/", authGuard, async (req, res) => {
  if (req.user.role === "guest" || req.user.role === "sluzhba") {
    return res.status(403).json({ error: "нет прав на создание заявок" });
  }

  const { equipmentId, issue, departments } = req.body || {};
  if (!equipmentId || !issue)
    return res.status(400).json({ error: "equipmentId и issue обязательны" });

  const eq = await prisma.equipment.findUnique({
    where: { id: Number(equipmentId) },
  });
  if (!eq) return res.status(400).json({ error: "Оборудование не найдено" });

  if (req.user.role === "uchastok" && eq.areaId !== req.user.areaId) {
    return res.status(403).json({ error: "нет доступа к этому оборудованию" });
  }

  const created = await prisma.workOrder.create({
    data: {
      equipmentId: eq.id,
      areaId: eq.areaId,
      objectName: eq.name,
      issue,
      issuedById: req.user.id,
      status: "NOVAYA",
      assignments: {
        create: (departments || []).map((id) => ({
          department: { connect: { id } },
        })),
      },
    },
    include: {
      equipment: { include: { area: true } },
      area: true,
      assignments: { include: { department: true } },
      issuedBy: true,
      comments: { include: { author: true }, orderBy: { createdAt: "asc" } },
    },
  });

  const mat = materializeWorkOrder(created);
  await notifyNewWorkOrder(mat, req.user.id);
  res.status(201).json(mat);
});

// -----------------------------------------------------------------------------
// 📌 Получить заявку по ID
// -----------------------------------------------------------------------------
router.get("/:id", authGuard, async (req, res) => {
  const id = Number(req.params.id);
  const item = await prisma.workOrder.findUnique({
    where: { id },
    include: {
      equipment: { include: { area: true } },
      area: true,
      assignments: { include: { department: true } },
      attachments: true,
      issuedBy: true,
      acceptedBy: true,
      completedBy: { include: { user: true } }, // 🔹
      comments: { include: { author: true }, orderBy: { createdAt: "asc" } },
    },
  });
  if (!item) return res.status(404).json({ error: "not found" });

  if (req.user?.id) {
    await prisma.unreadWorkOrder.deleteMany({
      where: { userId: req.user.id, orderId: id },
    });
  }

  res.json(materializeWorkOrder(item));
});

// -----------------------------------------------------------------------------
// 📌 Принять в работу
// -----------------------------------------------------------------------------
router.post("/:id/accept", authGuard, async (req, res) => {
  if (req.user.role === "guest") {
    return res.status(403).json({ error: "guest cannot accept orders" });
  }

  const id = Number(req.params.id);
  const assignment = await prisma.workOrderAssignment.findFirst({
    where: { workOrderId: id, departmentId: req.user.departmentId },
  });
  if (!assignment) return res.status(403).json({ error: "нет доступа" });

  if (assignment.status !== "NOVAYA") {
    return res.status(400).json({ error: "уже принято" });
  }

  await prisma.workOrderAssignment.update({
    where: { id: assignment.id },
    data: { status: "V_RABOTE" },
  });

  const all = await prisma.workOrderAssignment.findMany({ where: { workOrderId: id } });
  if (all.every((a) => a.status === "V_RABOTE")) {
    await prisma.workOrder.update({
      where: { id },
      data: { status: "V_RABOTE", acceptedById: req.user.id, acceptedAt: new Date() },
    });
  }

  const updated = await prisma.workOrder.findUnique({
    where: { id },
    include: {
      assignments: { include: { department: true } },
      equipment: { include: { area: true } },
      area: true,
      comments: { include: { author: true } },
    },
  });

  const mat = materializeWorkOrder(updated);
  await notifyStatusChanged(mat);
  res.json(mat);
});

// -----------------------------------------------------------------------------
// 📌 Завершить заявку (с несколькими исполнителями)
// -----------------------------------------------------------------------------
router.post("/:id/complete", authGuard, async (req, res) => {
  if (req.user.role === "guest") {
    return res.status(403).json({ error: "guest cannot complete orders" });
  }

  const id = Number(req.params.id);
  const { note, completedByIds } = req.body || {};

  const assignment = await prisma.workOrderAssignment.findFirst({
    where: { workOrderId: id, departmentId: req.user.departmentId },
  });
  if (!assignment) return res.status(403).json({ error: "нет доступа" });

  if (assignment.status !== "V_RABOTE") {
    return res.status(400).json({ error: "сначала примите заявку" });
  }

  await prisma.workOrderAssignment.update({
    where: { id: assignment.id },
    data: { status: "ZAVERSHENA" },
  });

  const all = await prisma.workOrderAssignment.findMany({ where: { workOrderId: id } });

  let updated;
  if (all.every((a) => a.status === "ZAVERSHENA")) {
    updated = await prisma.workOrder.update({
      where: { id },
      data: {
        status: "ZAVERSHENA",
        completedAt: new Date(),
        note,
        completedBy: {
          create: (completedByIds?.length ? completedByIds : [req.user.id]).map((uid) => ({
            user: { connect: { id: uid } },
          })),
        },
      },
      include: {
        assignments: { include: { department: true } },
        equipment: { include: { area: true } },
        area: true,
        comments: { include: { author: true } },
        completedBy: { include: { user: true } },
      },
    });
  } else {
    updated = await prisma.workOrder.findUnique({
      where: { id },
      include: {
        assignments: { include: { department: true } },
        equipment: { include: { area: true } },
        area: true,
        comments: { include: { author: true } },
        completedBy: { include: { user: true } },
      },
    });
  }

  const mat = materializeWorkOrder(updated);
  await notifyStatusChanged(mat);
  res.json(mat);
});

// -----------------------------------------------------------------------------
// 📌 Комментарии
// -----------------------------------------------------------------------------
router.post("/:id/comment", authGuard, async (req, res) => {
  if (req.user.role === "guest") {
    return res.status(403).json({ error: "guest cannot comment" });
  }

  const id = Number(req.params.id);
  const { text } = req.body || {};
  if (!text) return res.status(400).json({ error: "text обязателен" });

  const saved = await prisma.comment.create({
    data: { text, orderId: id, authorId: req.user.id },
    include: { author: true },
  });

  notifyCommentAdded(id, saved);
  res.json(saved);
});

// -----------------------------------------------------------------------------
// 📌 Вложения
// -----------------------------------------------------------------------------
router.post("/:id/attachments", authGuard, upload.single("file"), async (req, res) => {
  if (req.user.role === "guest") {
    return res.status(403).json({ error: "guest cannot upload files" });
  }

  const id = Number(req.params.id);
  if (!req.file) return res.status(400).json({ error: "Файл обязателен" });

  const saved = await prisma.workOrderAttachment.create({
    data: {
      orderId: id,
      fileName: req.file.originalname,
      fileUrl: `/uploads/${req.file.filename}`,
    },
  });

  notifyAttachmentAdded(id, saved);
  res.json(saved);
});

router.get("/:id/attachments", authGuard, async (req, res) => {
  const id = Number(req.params.id);
  const files = await prisma.workOrderAttachment.findMany({
    where: { orderId: id },
    orderBy: { createdAt: "asc" },
  });
  res.json(files);
});

export default router;
