// backend/src/enums.js

// -------------------------------------------------
// 🔹 ENUM MAPS
// -------------------------------------------------
export const AreaMap = {
  GTP: "ГТП",
  CPPR: "ЦППР",
  AC: "АЦ",
  TNS: "ТНС",
};
const AreaMapRev = Object.fromEntries(
  Object.entries(AreaMap).map(([k, v]) => [v, k])
);

export const WorkStatusMap = {
  NOVAYA: "новая",
  V_RABOTE: "в работе",
  ZAVERSHENA: "завершена",
};
const WorkStatusMapRev = Object.fromEntries(
  Object.entries(WorkStatusMap).map(([k, v]) => [v, k])
);

export const EquipStatusMap = {
  RABOTAET: "работает",
  PLAN_TO: "план ТО",
  AVARIYA: "авария",
  V_REZERVE: "в резерве",
};
const EquipStatusMapRev = Object.fromEntries(
  Object.entries(EquipStatusMap).map(([k, v]) => [v, k])
);

// -------------------------------------------------
// 🔹 Converters
// -------------------------------------------------
export function fromEnumArea(code) {
  return AreaMap[code] || code;
}
export function toEnumArea(v) {
  if (!v) return undefined;
  return AreaMapRev[v] || v;
}

export function fromEnumWorkStatus(code) {
  return WorkStatusMap[code] || code;
}
export function toEnumWorkStatus(v) {
  if (!v) return undefined;
  return WorkStatusMapRev[v] || v;
}

export function fromEnumEquipStatus(code) {
  return EquipStatusMap[code] || code;
}
export function toEnumEquipStatus(v) {
  if (!v) return undefined;
  return EquipStatusMapRev[v] || v;
}

// -------------------------------------------------
// 🔹 Materializers
// -------------------------------------------------
export function materializeEquipment(row) {
  if (!row) return row;
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    position: row.position,
    serial: row.serial,
    area: row.area
      ? {
          id: row.area.id,
          name: fromEnumArea(row.area.name),
        }
      : null,
    status: fromEnumEquipStatus(row.status),
    createdAt: row.createdAt,
  };
}

export function materializeWorkOrder(row) {
  if (!row) return row;

  const assignments = row.assignments?.map((a) => ({
    id: a.id,
    status: fromEnumWorkStatus(a.status),
    department: a.department
      ? { id: a.department.id, name: a.department.name }
      : null,
  })) || [];

  return {
    id: row.id,
    equipmentId: row.equipmentId,
    equipment: row.equipment ? materializeEquipment(row.equipment) : undefined,

    area: row.area
      ? { id: row.area.id, name: fromEnumArea(row.area.name) }
      : null,

    objectName: row.objectName,
    issue: row.issue,
    createdAt: row.createdAt,

    issuedBy: row.issuedBy
      ? { id: row.issuedBy.id, fio: row.issuedBy.fio, login: row.issuedBy.login }
      : null,

    acceptedBy: row.acceptedBy
      ? { id: row.acceptedBy.id, fio: row.acceptedBy.fio, login: row.acceptedBy.login }
      : null,
    acceptedAt: row.acceptedAt || null,

    status: fromEnumWorkStatus(row.status),

    completedBy: row.completedBy
      ? { id: row.completedBy.id, fio: row.completedBy.fio, login: row.completedBy.login }
      : null,
    completedAt: row.completedAt || null,
    note: row.note || null,

    assignments,
    assignedTo: assignments
      .filter((a) => a.department)
      .map((a) => ({ id: a.department.id, name: a.department.name })),

    attachments: row.attachments?.map((a) => ({
      id: a.id,
      fileName: a.fileName,
      fileUrl: a.fileUrl,
      createdAt: a.createdAt,
    })) || [],

    comments: row.comments?.map((c) => ({
      id: c.id,
      text: c.text,
      createdAt: c.createdAt,
      author: c.author
        ? { id: c.author.id, fio: c.author.fio, login: c.author.login }
        : null,
    })) || [],
  };
}
