iwr https://fly.io/install.ps1 -useb | iex
fly version
fly auth login
cd backend
fly launch --name equip-backend --region waw --no-deploy


docker-compose exec backend npx prisma migrate dev --name init
docker-compose exec backend npx prisma db seed

docker-compose down -v
docker-compose up -d --build db
docker-compose run --rm backend npx prisma migrate dev --name init
docker-compose run --rm backend npx prisma db seed
docker-compose up -d --build

docker-compose run --rm backend npx prisma migrate dev --name add_equipment_permissions
