import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,       // порт dev-сервера
    host: true,       // позволяет слушать на 0.0.0.0 (полезно в Docker/VM)
    strictPort: true  // упадёт, если порт занят, вместо того чтобы выбрать случайный
  },
  preview: {
    port: 4173,       // порт для vite preview (по умолчанию 4173)
    host: true
  },
  esbuild: {
    include: /src\/.*\.[jt]sx?$/,   // обрабатываем только .js/.ts/.jsx/.tsx
    exclude: /src\/api\.js$/,       // 👈 api.js исключаем из JSX-парсинга
  }
});
