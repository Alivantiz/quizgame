import { Outlet } from "react-router-dom";
import { useUser } from "../UserContext.jsx";

export default function ProtectedRoute() {
  const me = useUser();

  if (me === undefined) return null; // ждём загрузку профиля

  // ✅ всегда пускаем: guest, uchastok, sluzhba, viewer, admin
  return <Outlet />;
}
