import { useEffect, useState } from "react";
import { Alert } from "antd";
import { io } from "socket.io-client";

/**
 * 🔔 Глобальный баннер для службы
 * Показывается только у сотрудников службы (role = sluzhba)
 */
export default function OrderAlert({ me }) {
  const [visible, setVisible] = useState(false);
  const [order, setOrder] = useState(null);

  useEffect(() => {
    if (!me || me.role !== "sluzhba" || !me.departmentId) return;

    const base = (import.meta.env.VITE_API_URL || "http://localhost:8080/api")
      .replace(/\/api\/?$/, "");

    const socket = io(base, {
      transports: ["websocket"],
      withCredentials: true,
    });

    // 👨‍🔧 служба подписывается только на свой департамент
    socket.emit("joinDepartment", me.departmentId);

    const checkAndShow = (ord) => {
      const inDep = ord.assignedTo?.some((d) => d.id === me.departmentId);
      const isNew = ord.status === "новая" || ord.status === "NOVAYA";
      if (inDep && isNew) {
        setOrder(ord);
        setVisible(true);
        console.log("⚡ Alert triggered:", ord);
      }
    };

    // новая заявка
    socket.on("newWorkOrder", checkAndShow);

    // заявка снова стала «новая»
    socket.on("statusChanged", checkAndShow);

    return () => socket.disconnect();
  }, [me]);

  if (!visible || !order) return null;

  return (
    <div
      style={{
        position: "fixed",
        top: 20,
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 2000,
        animation: "blink 1.2s infinite",
        width: "90%",
        maxWidth: 500,
        borderRadius: 12,
        boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
      }}
    >
      <Alert
        message={`Новая заявка №${order.id}`}
        description={order.issue || "Создана новая заявка"}
        type="error"
        showIcon
        closable
        onClose={() => setVisible(false)}
      />
      <style>
        {`
          @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
          }
          .ant-alert {
            font-size: 16px;
            font-weight: 600;
            border-radius: 12px;
          }
        `}
      </style>
    </div>
  );
}
