import { Navigate, Outlet } from "react-router-dom";
import { useUser } from "../UserContext.jsx";

export default function AdminRoute() {
  const { me } = useUser(); // ⬅️ достаём именно me

  if (me === undefined) return null; // ждём загрузку профиля

  // если гость → не пускаем в админку
  if (!me || me.role === "guest") {
    return <Navigate to="/" replace />;
  }

  // доступ только админу
  return me.role?.toLowerCase() === "admin" ? (
    <Outlet />
  ) : (
    <Navigate to="/" replace />
  );
}
