import { createContext, useContext } from "react";

// Контекст для хранения информации о пользователе + метода обновления
export const UserContext = createContext({
  me: null,
  setMe: () => {},
});

export function useUser() {
  return useContext(UserContext);
}
