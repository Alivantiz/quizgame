import { useEffect, useState, useMemo } from "react";
import { Routes, Route, useNavigate, useLocation, Navigate } from "react-router-dom";
import { Layout, Menu, notification, Grid, Spin } from "antd";
import {
  DashboardOutlined,
  DatabaseOutlined,
  FileTextOutlined,
  UserOutlined,
  SettingOutlined,
} from "@ant-design/icons";
import { io } from "socket.io-client";

import ProtectedRoute from "./components/ProtectedRoute.jsx";
import AdminRoute from "./components/AdminRoute.jsx";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Catalog from "./pages/Catalog/Catalog.jsx";
import Workorders from "./pages/Workorders/Workorders.jsx";
import Profile from "./pages/Profile.jsx";
import Settings from "./pages/settings/index.jsx";
import api from "./api";
import { UserContext } from "./UserContext.jsx";
import OrderAlert from "./components/OrderAlert";

const { Header, Sider, Content } = Layout;

export default function App() {
  const nav = useNavigate();
  const location = useLocation();
  const route = location.pathname;

  const screens = Grid.useBreakpoint();
  const isMobile = !screens.md;

  const [me, setMe] = useState(undefined); // undefined = ждём, guest = неавторизован

  // авто-refresh access при старте
  useEffect(() => {
    (async () => {
      try {
        await api.post("/auth/refresh");
        const { data } = await api.get("/users/me");
        setMe(data);
      } catch {
        // 👉 если refresh не удался — считаем гостем
        setMe({ role: "guest" });
      }
    })();
  }, []);

  // socket-подключение (гостя пропускаем)
  useEffect(() => {
    if (!me || me.role === "guest") return;
    const base = (import.meta.env.VITE_API_URL || "http://localhost:8080/api")
      .replace(/\/api\/?$/, "");
    const socket = io(base, { transports: ["websocket"], withCredentials: true });

    socket.emit("joinUser", me.id);
    if (me.role === "admin") socket.emit("joinAdmin");

    const depId = me.departmentId ?? me.department?.id;
    if (me.role === "sluzhba" && depId) {
      socket.emit("joinDepartment", depId);
    }

    socket.on("newWorkOrder", (order) => {
      notification.info({
        message: "Новая заявка",
        description: order?.issue || "Создана новая заявка",
        placement: isMobile ? "topRight" : "bottomRight",
      });
    });

    socket.on("statusChanged", (order) => {
      notification.success({
        message: `Заявка №${order?.id}`,
        description: `Статус изменён: ${order?.status}`,
        placement: isMobile ? "topRight" : "bottomRight",
      });
    });

    return () => socket.disconnect();
  }, [me, isMobile]);

  // имя вкладки для профиля
  const profileLabel = me
    ? me.role === "guest"
      ? "Гость"
      : me.fio || "Профиль"
    : "Профиль";

  // верхнее меню
  const topItems = useMemo(
    () => [
      { key: "/", icon: <DashboardOutlined />, label: "Дашборд" },
      { key: "/catalog", icon: <DatabaseOutlined />, label: "Каталог" },
      { key: "/workorders", icon: <FileTextOutlined />, label: "Заявки" },
      { key: "/profile", icon: <UserOutlined />, label: profileLabel },
      ...(me?.role === "admin"
        ? [{ key: "/settings", icon: <SettingOutlined />, label: "Настройки" }]
        : []),
    ],
    [me, profileLabel]
  );

  const handleMenuClick = ({ key }) => {
    if (key !== route) nav(key);
  };

  // пока профиль грузится
  if (me === undefined) {
    return (
      <div style={{ display: "grid", placeItems: "center", height: "100vh" }}>
        <Spin size="large" />
      </div>
    );
  }

  return (
    <UserContext.Provider value={{ me, setMe }}>
      <Layout style={{ minHeight: "100dvh" }}>
        {!isMobile && route !== "/login" && (
          <Sider theme="dark" width={220} style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ color: "white", padding: 16, fontWeight: 600 }}>Южный Инкай</div>
            <Menu
              theme="dark"
              mode="inline"
              selectedKeys={[route]}
              items={topItems}
              onClick={handleMenuClick}
              style={{ flex: 1 }}
            />
          </Sider>
        )}

        <Layout>
          {route !== "/login" && (
            <Header style={{ background: "#fff" }}>
              {isMobile ? (
                <div style={{ fontWeight: 700, fontSize: 18, lineHeight: "22px" }}>
                  Equip Passports
                </div>
              ) : null}
            </Header>
          )}

          <Content style={{ margin: 16 }}>
            <Routes>
              <Route
                path="/login"
                element={
                  me && me.role !== "guest" ? (
                    <Navigate to="/" replace />
                  ) : (
                    <Login
                      onLogin={(user) => {
                        setMe(user);
                        nav("/");
                      }}
                    />
                  )
                }
              />
              <Route element={<ProtectedRoute />}>
                <Route path="/" element={<Dashboard />} />
                <Route path="/catalog" element={<Catalog />} />
                <Route path="/workorders" element={<Workorders />} />
                <Route path="/profile" element={<Profile />} />
                <Route element={<AdminRoute />}>
                  <Route path="/settings" element={<Settings />} />
                </Route>
              </Route>
            </Routes>
          </Content>
        </Layout>
      </Layout>

      <OrderAlert me={me} />
    </UserContext.Provider>
  );
}
