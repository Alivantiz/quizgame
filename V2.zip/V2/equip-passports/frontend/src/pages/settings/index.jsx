import { Card, Tabs, message } from "antd";
import { useState, useEffect } from "react";
import api from "../../api";
import UsersTab from "./UsersTab";
import DepartmentsTab from "./DepartmentsTab";
import AreasTab from "./AreasTab";

export default function Settings() {
  const [tab, setTab] = useState("users");
  const [deps, setDeps] = useState([]);
  const [areas, setAreas] = useState([]);

  // 🔹 загрузка подразделений
  const loadDeps = async () => {
    try {
      const { data } = await api.get("/departments");
      setDeps(data);
    } catch (e) {
      console.error("Ошибка загрузки подразделений", e);
      message.error("Не удалось загрузить подразделения");
    }
  };

  // 🔹 загрузка цехов
  const loadAreas = async () => {
    try {
      const { data } = await api.get("/areas");
      setAreas(data);
    } catch (e) {
      console.error("Ошибка загрузки цехов", e);
      message.error("Не удалось загрузить цеха");
    }
  };

  useEffect(() => {
    loadDeps();
    loadAreas();
  }, []);

  return (
    <Card title="Настройки">
      <Tabs
        activeKey={tab}
        onChange={setTab}
        destroyInactiveTabPane
        items={[
          {
            key: "users",
            label: "Пользователи",
            children: (
              <UsersTab
                deps={deps}
                areas={areas}
                reloadDeps={loadDeps}
                reloadAreas={loadAreas}
              />
            ),
          },
          {
            key: "departments",
            label: "Подразделения",
            children: (
              <DepartmentsTab deps={deps} reloadDeps={loadDeps} />
            ),
          },
          {
            key: "areas",
            label: "Цеха",
            children: <AreasTab areas={areas} reloadAreas={loadAreas} />,
          },
        ]}
      />
    </Card>
  );
}
