// src/pages/Settings/UsersTab.jsx
import { useEffect, useState } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  Select,
  message,
  Space,
  Card,
  Tag,
  Grid,
  Typography,
  Popconfirm,
} from "antd";
import api from "../../api";

export default function UsersTab({ deps, areas, reloadDeps, reloadAreas }) {
  const [users, setUsers] = useState([]);
  const [userOpen, setUserOpen] = useState(false);
  const [userForm] = Form.useForm();
  const [editUser, setEditUser] = useState(null);

  const screens = Grid.useBreakpoint();
  const isMobile = !screens.md;

  const loadUsers = async () => {
    try {
      const { data } = await api.get("/users");
      setUsers(data);
    } catch {
      message.error("Ошибка загрузки пользователей");
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const saveUser = async (v) => {
    try {
      let payload = {
        authId: v.authId,
        fio: v.fio,
        position: v.position,
        role: v.role,
        departmentId: null,
        areaId: null,
      };

      if (v.role === "sluzhba") payload.departmentId = v.departmentId;
      else if (v.role === "uchastok") payload.areaId = v.areaId;

      if (editUser) {
        await api.put(`/users/${editUser.id}`, payload);
        message.success("Пользователь обновлён");
      } else {
        await api.post("/users", payload);
        message.success("Пользователь добавлен");
      }

      setUserOpen(false);
      setEditUser(null);
      userForm.resetFields();
      loadUsers();
      reloadDeps();
      reloadAreas();
    } catch (e) {
      message.error(e.response?.data?.error || "Ошибка при сохранении пользователя");
    }
  };

  const deleteUser = async (id) => {
    try {
      await api.delete(`/users/${id}`);
      message.success("Пользователь удалён");
      loadUsers();
    } catch {
      message.error("Ошибка при удалении пользователя");
    }
  };

  const openEditUser = (u) => {
    setEditUser(u);
    userForm.setFieldsValue({
      authId: u.authId,
      fio: u.fio,
      position: u.position,
      role: u.role,
      departmentId: u.departmentId ?? u.department?.id ?? null,
      areaId: u.areaId ?? u.area?.id ?? null,
    });
    setUserOpen(true);
  };

  const renderBelongs = (u) => {
    const bt = u.belongsTo;
    if (bt?.type === "department") return `Служба: ${bt.name}`;
    if (bt?.type === "area") return `Участок: ${bt.name}`;
    return "-";
  };

  return (
    <>
      <Button
        type="primary"
        onClick={() => {
          setEditUser(null);
          userForm.resetFields();
          setUserOpen(true);
        }}
        style={{ marginBottom: 12 }}
      >
        Добавить пользователя
      </Button>

      {!isMobile && (
        <Table
          rowKey="id"
          dataSource={users}
          pagination={false}
          columns={[
            { title: "Auth ID", dataIndex: "authId" },
            { title: "ФИО", dataIndex: "fio" },
            { title: "Должность", dataIndex: "position" },
            { title: "Роль", dataIndex: "role" },
            { title: "Принадлежность", render: (_, rec) => renderBelongs(rec) },
            {
              title: "Действия",
              render: (_, rec) => (
                <Space>
                  <Button size="small" onClick={() => openEditUser(rec)}>
                    Редактировать
                  </Button>
                  <Popconfirm
                    title="Удалить пользователя?"
                    okText="Да"
                    cancelText="Нет"
                    onConfirm={() => deleteUser(rec.id)}
                  >
                    <Button size="small" danger>
                      Удалить
                    </Button>
                  </Popconfirm>
                </Space>
              ),
            },
          ]}
        />
      )}

      {isMobile && (
        <Space direction="vertical" style={{ width: "100%" }}>
          {users.map((u) => (
            <Card key={u.id} size="small" hoverable>
              <Typography.Text strong>{u.fio || u.authId}</Typography.Text>
              <div style={{ fontSize: 13, color: "#666" }}>{u.position}</div>
              <div style={{ marginTop: 6 }}>
                <Tag color="blue">{u.role}</Tag>
                {u.belongsTo?.type === "department" && (
                  <Tag color="green">Служба: {u.belongsTo.name}</Tag>
                )}
                {u.belongsTo?.type === "area" && (
                  <Tag color="purple">Участок: {u.belongsTo.name}</Tag>
                )}
              </div>
              <div style={{ marginTop: 8 }}>
                <Space>
                  <Button size="small" onClick={() => openEditUser(u)}>
                    Редактировать
                  </Button>
                  <Popconfirm
                    title="Удалить пользователя?"
                    okText="Да"
                    cancelText="Нет"
                    onConfirm={() => deleteUser(u.id)}
                  >
                    <Button size="small" danger>
                      Удалить
                    </Button>
                  </Popconfirm>
                </Space>
              </div>
            </Card>
          ))}
        </Space>
      )}

      <Modal
        title={editUser ? "Редактировать пользователя" : "Новый пользователь"}
        open={userOpen}
        onCancel={() => setUserOpen(false)}
        footer={null}
        destroyOnClose
      >
        <Form layout="vertical" form={userForm} onFinish={saveUser}>
          <Form.Item name="authId" label="Auth ID" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item name="fio" label="ФИО">
            <Input />
          </Form.Item>
          <Form.Item name="position" label="Должность">
            <Input />
          </Form.Item>

          <Form.Item name="role" label="Роль" rules={[{ required: true }]}>
            <Select
              onChange={() => {
                userForm.setFieldsValue({ departmentId: null, areaId: null });
              }}
              options={[
                { value: "admin", label: "Админ" },
                { value: "uchastok", label: "Участок" },
                { value: "sluzhba", label: "Служба" },
              ]}
            />
          </Form.Item>

          <Form.Item noStyle shouldUpdate>
            {({ getFieldValue }) => {
              const role = getFieldValue("role");
              if (role === "uchastok") {
                return (
                  <Form.Item
                    name="areaId"
                    label="Участок"
                    rules={[{ required: true, message: "Выберите участок" }]}
                  >
                    <Select
                      placeholder="Выберите участок"
                      options={areas.map((a) => ({ value: a.id, label: a.name }))}
                    />
                  </Form.Item>
                );
              }
              if (role === "sluzhba") {
                return (
                  <Form.Item
                    name="departmentId"
                    label="Служба"
                    rules={[{ required: true, message: "Выберите службу" }]}
                  >
                    <Select
                      placeholder="Выберите службу"
                      options={deps.map((d) => ({ value: d.id, label: d.name }))}
                    />
                  </Form.Item>
                );
              }
              return null;
            }}
          </Form.Item>

          <Button type="primary" htmlType="submit" block>
            Сохранить
          </Button>
        </Form>
      </Modal>
    </>
  );
}
