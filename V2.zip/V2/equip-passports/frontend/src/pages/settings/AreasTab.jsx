import { useState } from "react";
import {
  Table,
  Button,
  Modal,
  Form,
  Input,
  message,
  Space,
  Tooltip,
  Popconfirm,
} from "antd";
import api from "../../api";

export default function AreasTab({ areas, reloadAreas }) {
  const [areaOpen, setAreaOpen] = useState(false);
  const [areaForm] = Form.useForm();
  const [areaDetail, setAreaDetail] = useState(null);
  const [renameForm] = Form.useForm();
  const [areaUsers, setAreaUsers] = useState([]);

  // создать новый цех
  const createArea = async (v) => {
    try {
      await api.post("/areas", v);
      message.success("Цех добавлен");
      setAreaOpen(false);
      areaForm.resetFields();
      reloadAreas();
    } catch (e) {
      message.error(e.response?.data?.error || "Ошибка при добавлении цеха");
    }
  };

  // открыть детали цеха
  const openAreaDetail = async (area) => {
    setAreaDetail(area);
    renameForm.setFieldsValue({ name: area.name });
    try {
      const { data } = await api.get(`/users?areaId=${area.id}`); // 🔹 фильтруем на бэке
      setAreaUsers(data);
    } catch {
      message.error("Ошибка загрузки пользователей");
    }
  };

  // переименовать цех
  const renameArea = async (v) => {
    try {
      await api.put(`/areas/${areaDetail.id}`, v);
      message.success("Название обновлено");
      setAreaDetail(null);
      reloadAreas();
    } catch (e) {
      message.error(e.response?.data?.error || "Ошибка при обновлении");
    }
  };

  // удалить цех
  const deleteArea = async () => {
    try {
      await api.delete(`/areas/${areaDetail.id}`);
      message.success("Цех удалён");
      setAreaDetail(null);
      reloadAreas();
    } catch (e) {
      message.error(e.response?.data?.error || "Ошибка при удалении");
    }
  };

  return (
    <>
      <Button
        type="primary"
        onClick={() => setAreaOpen(true)}
        style={{ marginBottom: 12 }}
      >
        Добавить цех
      </Button>

      <Table
        rowKey="id"
        dataSource={areas}
        pagination={false}
        columns={[{ title: "Название", dataIndex: "name" }]}
        onRow={(area) => ({
          onClick: () => openAreaDetail(area),
          style: { cursor: "pointer" },
        })}
      />

      {/* модалка создания */}
      <Modal
        title="Новый цех"
        open={areaOpen}
        onCancel={() => setAreaOpen(false)}
        footer={null}
        destroyOnClose
      >
        <Form layout="vertical" form={areaForm} onFinish={createArea}>
          <Form.Item
            name="name"
            label="Название"
            rules={[{ required: true, message: "Введите название" }]}
          >
            <Input />
          </Form.Item>
          <Button type="primary" htmlType="submit" block>
            Сохранить
          </Button>
        </Form>
      </Modal>

      {/* модалка деталей */}
      <Modal
        title={`Цех: ${areaDetail?.name}`}
        open={!!areaDetail}
        onCancel={() => setAreaDetail(null)}
        footer={null}
        destroyOnClose
      >
        <Form layout="vertical" form={renameForm} onFinish={renameArea}>
          <Form.Item
            name="name"
            label="Название"
            rules={[{ required: true, message: "Введите название" }]}
          >
            <Input />
          </Form.Item>
          <Space style={{ display: "flex", justifyContent: "space-between" }}>
            <Button type="primary" htmlType="submit">
              Сохранить
            </Button>
            <Tooltip
              title={
                areaUsers.length > 0
                  ? "Нельзя удалить цех с пользователями"
                  : ""
              }
            >
              <Popconfirm
                title="Удалить цех?"
                okText="Да"
                cancelText="Нет"
                onConfirm={deleteArea}
                disabled={areaUsers.length > 0}
              >
                <Button danger disabled={areaUsers.length > 0}>
                  Удалить
                </Button>
              </Popconfirm>
            </Tooltip>
          </Space>
        </Form>

        <Table
          rowKey="id"
          dataSource={areaUsers}
          pagination={false}
          style={{ marginTop: 16 }}
          columns={[
            { title: "Логин", dataIndex: "authId" },
            { title: "ФИО", dataIndex: "fio" },
            { title: "Должность", dataIndex: "position" },
            { title: "Роль", dataIndex: "role" },
          ]}
        />
      </Modal>
    </>
  );
}
