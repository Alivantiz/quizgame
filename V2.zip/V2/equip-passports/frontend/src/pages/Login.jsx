// src/pages/Login.jsx
import { Card, Form, Input, Button, message } from "antd";
import api from "../api";
import { useUser } from "../UserContext.jsx";

export default function Login({ onLogin }) {
  const { setMe } = useUser(); // глобальный сеттер пользователя

  const onFinish = async (values) => {
    try {
      const { data } = await api.post("/auth/login", { authId: values.authId });
      if (data?.user) {
        setMe(data.user);              // обновляем глобального пользователя
        if (onLogin) onLogin(data.user); // вызываем локальный хендлер (например, открыть модалку)
        message.success("Успешный вход");
      } else {
        message.error("Ошибка входа: нет данных пользователя");
      }
    } catch (e) {
      message.error(e.response?.data?.error || "Не удалось войти. Проверьте ID.");
    }
  };

  return (
    <Card style={{ width: "100%" }}>
      <Form layout="vertical" onFinish={onFinish}>
        <Form.Item
          label="Ваш ID"
          name="authId"
          rules={[{ required: true, message: "Введите ваш ID" }]}
        >
          <Input autoFocus />
        </Form.Item>
        <Button type="primary" htmlType="submit" block>
          Войти
        </Button>
      </Form>
    </Card>
  );
}
