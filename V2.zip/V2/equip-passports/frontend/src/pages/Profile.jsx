import { Card, Form, Input, Button, message, Space, Typography } from "antd";
import { LogoutOutlined } from "@ant-design/icons";
import api from "../api";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../UserContext.jsx";
import Login from "./Login.jsx"; // 👈 используем готовую форму авторизации

export default function Profile() {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [meLocal, setMeLocal] = useState(null);
  const nav = useNavigate();
  const { me: globalMe, setMe } = useUser();

  // 🔹 Загружаем профиль только если не гость
  useEffect(() => {
    if (!globalMe || globalMe.role === "guest") return;
    (async () => {
      try {
        const { data } = await api.get("/users/me");
        setMeLocal(data);
        form.setFieldsValue(data);
      } catch {
        /* ignore */
      }
    })();
  }, [globalMe]);

  // 🔹 Сохранение профиля
  const onSave = async (v) => {
    setLoading(true);
    try {
      await api.put("/users/me", v);
      message.success("Профиль сохранён");
      const { data } = await api.get("/users/me");
      setMeLocal(data);
    } finally {
      setLoading(false);
    }
  };

  // 🔹 Выход
  const onLogout = async () => {
    try {
      await api.post("/auth/logout");
    } catch {
      /* ignore */
    }
    setMe({ role: "guest" });
    nav("/", { replace: true });
  };

  // 🔹 Если гость — показываем Login.jsx (одно поле ID)
  if (globalMe?.role === "guest") {
    return (
      <Card title="Авторизация по ID">
        <Login
          onLogin={(user) => {
            setMe(user);
            nav("/", { replace: true });
          }}
        />
      </Card>
    );
  }

  // 🔹 Профиль авторизованного пользователя
  return (
    <Space direction="vertical" style={{ width: "100%" }} size="large">
      <Card title="Профиль">
        <Form layout="vertical" form={form} onFinish={onSave}>
          <Form.Item label="ФИО" name="fio">
            <Input />
          </Form.Item>
          <Form.Item label="Должность" name="position">
            <Input />
          </Form.Item>

          {meLocal && (
            <>
              <Typography.Text>
                <b>Категория:</b>{" "}
                {meLocal.role === "uchastok"
                  ? "Участок"
                  : meLocal.role === "sluzhba"
                  ? "Служба"
                  : meLocal.role === "admin"
                  ? "Админ"
                  : meLocal.role}
              </Typography.Text>
              <br />
              {meLocal.role === "uchastok" && meLocal.area && (
                <Typography.Text>
                  <b>Участок:</b> {meLocal.area.name}
                </Typography.Text>
              )}
              {meLocal.role === "sluzhba" && meLocal.department && (
                <Typography.Text>
                  <b>Служба:</b> {meLocal.department.name}
                </Typography.Text>
              )}
            </>
          )}

          <div style={{ marginTop: 16 }}>
            <Button type="primary" htmlType="submit" loading={loading}>
              Сохранить
            </Button>
          </div>
        </Form>
      </Card>

      <Card>
        <Typography.Text type="secondary">Управление сессией</Typography.Text>
        <div style={{ marginTop: 12 }}>
          <Button
            danger
            icon={<LogoutOutlined />}
            onClick={onLogout}
            size="large"
            style={{ width: "100%" }}
          >
            Выйти из аккаунта
          </Button>
        </div>
      </Card>
    </Space>
  );
}
