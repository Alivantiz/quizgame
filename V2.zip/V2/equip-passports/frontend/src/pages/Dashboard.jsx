// src/pages/Dashboard.jsx
import { useEffect, useState } from "react";
import { Card, Row, Col, Statistic, Spin } from "antd";
import {
  CheckCircleOutlined,
  ClockCircleOutlined,
  WarningOutlined,
  AppstoreOutlined,
} from "@ant-design/icons";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import api from "../api";

const COLORS_ORDERS = ["#1890ff", "#faad14", "#52c41a"]; // новые, в работе, завершены
const COLORS_EQUIP = ["#52c41a", "#f5222d", "#faad14"]; // работает, авария, резерв

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get("/dashboard");
        setStats(data);
      } catch (e) {
        console.error("Ошибка загрузки дашборда:", e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <div style={{ display: "grid", placeItems: "center", height: "100vh" }}>
        <Spin size="large" />
      </div>
    );
  }

  if (!stats) {
    return <div style={{ padding: 16 }}>Ошибка загрузки данных</div>;
  }

  const workOrdersData = [
    { name: "Новые", value: stats.workOrders.new },
    { name: "В работе", value: stats.workOrders.inProgress },
    { name: "Завершены", value: stats.workOrders.completed },
  ];

  const equipmentData = [
    { name: "Работает", value: stats.equipment.working },
    { name: "Авария", value: stats.equipment.repair },
    { name: "В резерве", value: stats.equipment.reserve },
  ];

  return (
    <div style={{ padding: 16 }}>
      <Row gutter={[16, 16]}>
        <Col xs={24} md={6}>
          <Card>
            <Statistic
              title="Всего заявок"
              value={stats.workOrders.total}
              prefix={<AppstoreOutlined />}
            />
          </Card>
        </Col>
        <Col xs={24} md={6}>
          <Card>
            <Statistic
              title="Новые"
              value={stats.workOrders.new}
              prefix={<ClockCircleOutlined />}
            />
          </Card>
        </Col>
        <Col xs={24} md={6}>
          <Card>
            <Statistic
              title="В работе"
              value={stats.workOrders.inProgress}
              prefix={<WarningOutlined />}
            />
          </Card>
        </Col>
        <Col xs={24} md={6}>
          <Card>
            <Statistic
              title="Завершены"
              value={stats.workOrders.completed}
              prefix={<CheckCircleOutlined />}
            />
          </Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]} style={{ marginTop: 20 }}>
        <Col xs={24} md={12}>
          <Card title="Распределение заявок">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={workOrdersData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label
                >
                  {workOrdersData.map((_, i) => (
                    <Cell key={i} fill={COLORS_ORDERS[i % COLORS_ORDERS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value, name) => [`${value}`, name]} />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </Col>

        <Col xs={24} md={12}>
          <Card title="Состояние оборудования">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={equipmentData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label
                >
                  {equipmentData.map((_, i) => (
                    <Cell key={i} fill={COLORS_EQUIP[i % COLORS_EQUIP.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value, name) => [`${value}`, name]} />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
