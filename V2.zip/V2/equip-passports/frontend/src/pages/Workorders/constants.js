// src/pages/Workorders/constants.js

export const STATUS_COLORS = {
  новая: "gold",        // заявка создана, ждёт принятия
  "в работе": "blue",   // заявка выполняется
  завершена: "green",   // заявка закрыта
};
