// src/pages/Workorders/CreateOrderModal.jsx
import { Modal, Form, Input, Select, Button, message, Tag } from "antd";
import { useState, useEffect, useContext } from "react";
import api from "../../api";
import { UserContext } from "../../UserContext.jsx";

export default function CreateOrderModal({
  open,
  onClose,
  isEdit = false,
  initialValues = null,
  onSaved,
}) {
  const me = useContext(UserContext);
  const [form] = Form.useForm();

  const [area, setArea] = useState();
  const [areas, setAreas] = useState([]);
  const [equipOptions, setEquipOptions] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [selectedDeps, setSelectedDeps] = useState([]);

  // утилиты для корректного извлечения id
  const myAreaId =
    me?.areaId ?? (me?.belongsTo?.type === "area" ? me.belongsTo.id : undefined);
  const myAreaName =
    me?.areaName ?? (me?.belongsTo?.type === "area" ? me.belongsTo.name : undefined);

  const myDepId =
    me?.departmentId ?? (me?.belongsTo?.type === "department" ? me.belongsTo.id : undefined);
  const myDepName =
    me?.departmentName ?? (me?.belongsTo?.type === "department" ? me.belongsTo.name : undefined);

  const isUch = (me?.role || "").toLowerCase() === "uchastok";
  const isSluzhba = (me?.role || "").toLowerCase() === "sluzhba";

  // 🔹 загрузка цехов
  useEffect(() => {
    if (!open) return;
    if (isUch) {
      setAreas(myAreaId ? [{ id: myAreaId, name: myAreaName || `Цех #${myAreaId}` }] : []);
    } else {
      api.get("/areas")
        .then(({ data }) => setAreas(data))
        .catch(() => message.error("Ошибка загрузки цехов"));
    }
  }, [open, isUch, myAreaId, myAreaName]);

  // 🔹 загрузка подразделений
  useEffect(() => {
    if (!open) return;
    if (isSluzhba && myDepId) {
      setDepartments([{ id: myDepId, name: myDepName || `Подразделение #${myDepId}` }]);
    } else {
      api.get("/departments")
        .then(({ data }) => setDepartments(data))
        .catch(() => message.error("Ошибка загрузки подразделений"));
    }
  }, [open, isSluzhba, myDepId, myDepName]);

  // 🔹 загрузка оборудования
  useEffect(() => {
    if (!open) return;

    const fill = (list) =>
      setEquipOptions(list.map((e) => ({
        label: `${e.name} (${e.position || "-"})`,
        value: e.id,
      })));

    if (isUch) {
      api.get("/equipment")
        .then(({ data }) => fill(data))
        .catch(() => message.error("Ошибка загрузки оборудования"));
    } else if (area) {
      api.get(`/equipment?areaId=${area}`)
        .then(({ data }) => fill(data))
        .catch(() => message.error("Ошибка загрузки оборудования"));
    } else {
      setEquipOptions([]);
    }
  }, [open, isUch, area]);

  // 🔹 установка начальных значений формы
  useEffect(() => {
    if (!open) return;

    if (isEdit && initialValues) {
      form.setFieldsValue({
        areaId: initialValues.area?.id ?? initialValues.areaId ?? (isUch ? myAreaId : undefined),
        equipmentId: initialValues.equipment?.id,
        issue: initialValues.issue,
        departments: initialValues.assignedTo?.map((d) => d.id) || [],
      });
      setArea(initialValues.area?.id ?? initialValues.areaId ?? (isUch ? myAreaId : undefined));
      setSelectedDeps(initialValues.assignedTo?.map((d) => d.id) || []);
    } else {
      form.resetFields();

      if (isUch && myAreaId) {
        form.setFieldValue("areaId", myAreaId);
        setArea(myAreaId);
      }

      setSelectedDeps(isSluzhba && myDepId ? [myDepId] : []);

      if (initialValues?.equipmentId) {
        form.setFieldValue("equipmentId", initialValues.equipmentId);
        const a = initialValues.area?.id || initialValues.areaId || (isUch ? myAreaId : undefined);
        if (a) {
          form.setFieldValue("areaId", a);
          setArea(a);
        }
      }
    }
  }, [isEdit, open, initialValues, isUch, myAreaId, isSluzhba, myDepId, form]);

  // 🔹 сохранение
  const onSubmit = async (v) => {
    try {
      if (!selectedDeps.length) {
        message.error("Нужно выбрать хотя бы одно подразделение");
        return;
      }

      if (isEdit && initialValues) {
        await api.put(`/workorders/${initialValues.id}`, {
          issue: v.issue,
          departments: selectedDeps,
        });
        message.success("Заявка обновлена");
      } else {
        await api.post("/workorders", {
          equipmentId: v.equipmentId,
          issue: v.issue,
          departments: selectedDeps,
        });
        message.success("Заявка создана");
      }
      onSaved && onSaved();
      onClose();
    } catch {
      message.error(isEdit ? "Не удалось обновить заявку" : "Не удалось создать заявку");
    }
  };

  return (
    <Modal
      open={open}
      title={isEdit ? `Редактировать заявку №${initialValues?.id}` : "Новая заявка"}
      onCancel={onClose}
      footer={null}
      destroyOnClose
    >
      <Form layout="vertical" form={form} onFinish={onSubmit}>
        {/* 🔹 Цех */}
        <Form.Item name="areaId" label="Цех" rules={[{ required: true }]}>
          <Select
            options={
              isUch
                ? myAreaId
                  ? [{ label: myAreaName || `Цех #${myAreaId}`, value: myAreaId }]
                  : []
                : areas.map((a) => ({ label: a.name, value: a.id }))
            }
            onChange={setArea}
            disabled={isUch}
          />
        </Form.Item>

        {/* 🔹 Оборудование */}
        <Form.Item name="equipmentId" label="Оборудование" rules={[{ required: true }]}>
          <Select
            options={equipOptions}
            disabled={(!isUch && !area) || (isEdit && !!initialValues?.equipmentId)}
            showSearch
            optionFilterProp="label"
          />
        </Form.Item>

        {/* 🔹 Неисправность */}
        <Form.Item name="issue" label="Неисправность" rules={[{ required: true }]}>
          <Input.TextArea rows={3} />
        </Form.Item>

        {/* 🔹 Подразделения */}
        <Form.Item
          name="departments"
          label="Назначить подразделения"
          rules={[{ required: true, message: "Выберите хотя бы одно подразделение" }]}
        >
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {departments.map((dep) => (
              <Tag.CheckableTag
                key={dep.id}
                checked={selectedDeps.includes(dep.id)}
                onChange={(checked) => {
                  const next = checked
                    ? [...selectedDeps, dep.id]
                    : selectedDeps.filter((id) => id !== dep.id);
                  setSelectedDeps(next);
                  form.setFieldValue("departments", next);
                }}
              >
                {dep.name}
              </Tag.CheckableTag>
            ))}
          </div>
        </Form.Item>

        <Button type="primary" htmlType="submit" block>
          {isEdit ? "Сохранить изменения" : "Создать заявку"}
        </Button>
      </Form>
    </Modal>
  );
}
