// src/pages/Workorders/OrderDetailModal.jsx
import {
  Modal,
  Button,
  Tag,
  Form,
  Input,
  Space,
  message,
  Upload,
  Tabs,
  Select,
} from "antd";
import { UploadOutlined } from "@ant-design/icons";
import api from "../../api";
import { STATUS_COLORS } from "./constants";
import { useEffect, useState, useContext } from "react";
import { io } from "socket.io-client";
import PassportModal from "../Catalog/PassportModal.jsx";
import imageCompression from "browser-image-compression";
import CreateOrderModal from "./CreateOrderModal.jsx";
import { UserContext } from "../../UserContext.jsx";

export default function OrderDetailModal({ orderId, onClose }) {
  const { me } = useContext(UserContext);

  const [form] = Form.useForm();
  const [uploading, setUploading] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [order, setOrder] = useState(null);
  const [commentText, setCommentText] = useState("");
  const [showPassport, setShowPassport] = useState(null);
  const [showEdit, setShowEdit] = useState(false);
  const [userOptions, setUserOptions] = useState([]);

  // 🔹 загрузка заявки
  const loadOrder = async () => {
    if (!orderId) return;
    try {
      const { data } = await api.get(`/workorders/${orderId}`);
      setOrder(data);
    } catch (err) {
      if (err.response?.status === 403) {
        message.warning("У вас нет доступа к этой заявке");
        onClose();
      } else {
        message.error("Ошибка загрузки заявки");
      }
    }
  };

  useEffect(() => {
    loadOrder();
    if (!orderId) return;

    const base = (import.meta.env.VITE_API_URL || "http://localhost:8080/api")
      .replace(/\/api\/?$/, "");
    const socket = io(base, { transports: ["websocket"], withCredentials: true });

    socket.on("commentAdded", (payload) => {
      if (payload.orderId === orderId) {
        setOrder((prev) => ({
          ...prev,
          comments: [...(prev?.comments || []), payload.comment],
        }));
      }
    });

    socket.on("attachmentAdded", (payload) => {
      if (payload.orderId === orderId) {
        setOrder((prev) => ({
          ...prev,
          attachments: [...(prev?.attachments || []), payload.attachment],
        }));
      }
    });

    socket.on("orderUpdated", (updated) => {
      if (updated.id === orderId) setOrder(updated);
    });

    socket.on("statusChanged", (updated) => {
      if (updated.id === orderId) setOrder(updated);
    });

    return () => socket.disconnect();
  }, [orderId]);

  if (!orderId || !order) return null;

  // 🔹 роль
  const role = (me?.role || "").toLowerCase().trim();
  const isAdmin = role === "admin";
  const isSluzhba = role === "sluzhba";
  const isAuthor = order.issuedBy?.id === me?.id;

  // 🔹 статус
  const statusRaw = (order.status || "").toLowerCase().trim();
  const isNew = statusRaw === "новая" || statusRaw === "novaya";
  const isInWork = statusRaw === "в работе" || statusRaw === "v_rabote";
  const isDone = statusRaw === "завершена" || statusRaw === "zavershena";

  // 🔹 назначение
  const isAssignedDep =
    isSluzhba &&
    me?.departmentId &&
    order.assignments?.some((a) => a.department?.id === me.departmentId);

  // 🔹 права
  const canAccept = isAdmin || isAssignedDep;
  const canComplete = isAdmin || isAssignedDep;
  const canEdit = isAdmin || (isAuthor && isNew);
  const canReopen = isAdmin || (isAuthor && isDone);

  // 🔹 действия
  const acceptOrder = async () => {
    try {
      const { data } = await api.post(`/workorders/${order.id}/accept`);
      setOrder(data);
      message.success("Заявка принята");
      onClose();
    } catch {
      message.error("Не удалось принять заявку");
    }
  };

  const completeOrder = async (v) => {
    try {
      setCompleting(true);

      const completedByIds = (v.completedBy || []).map((u) => u.value);

      const { data } = await api.post(`/workorders/${order.id}/complete`, {
        note: v.note || undefined,
        completedByIds,
      });

      setOrder(data);
      message.success("Заявка завершена");
      onClose();
    } catch {
      message.error("Не удалось завершить заявку");
    } finally {
      setCompleting(false);
    }
  };

  const reopenOrder = async () => {
    try {
      const { data } = await api.post(`/workorders/${order.id}/reopen`, {
        reason: "Отправлена на доработку",
      });
      setOrder(data);
      message.success("Заявка возвращена на доработку");
    } catch {
      message.error("Не удалось вернуть заявку на доработку");
    }
  };

  const addComment = async () => {
    if (!commentText.trim()) return;
    try {
      const { data } = await api.post(`/workorders/${order.id}/comment`, {
        text: commentText,
      });
      setOrder((prev) => ({
        ...prev,
        comments: [...(prev?.comments || []), data],
      }));
      setCommentText("");
    } catch {
      message.error("Не удалось добавить комментарий");
    }
  };

  const beforeUpload = async (file) => {
    try {
      const options = {
        maxSizeMB: 1,
        maxWidthOrHeight: 1920,
        useWebWorker: true,
      };
      return await imageCompression(file, options);
    } catch {
      return file;
    }
  };

  // ===== Основное =====
  const mainTab = (
    <Space direction="vertical" style={{ width: "100%" }}>
      <div>
        <b>Объект:</b>{" "}
        <Button type="link" onClick={() => setShowPassport(order.equipment)}>
          {order.equipment?.name || order.objectName}
        </Button>
      </div>
      <div>
        <b>Цех:</b> {order.area?.name || order.area || "—"}
      </div>
      <div>
        <b>Неисправность:</b> {order.issue}
      </div>
      <div>
        <b>Выдал:</b> {order.issuedBy?.fio || "—"}
      </div>
      <div>
        <b>Статус:</b>{" "}
        <Tag color={STATUS_COLORS[order.status]}>{order.status}</Tag>
      </div>

      {order.acceptedBy && (
        <div>
          <b>Принял в работу:</b> {order.acceptedBy.fio || "—"}
        </div>
      )}

      {isNew && (
        <Space wrap>
          {canAccept && (
            <Button type="primary" onClick={acceptOrder}>
              Принять в работу
            </Button>
          )}
          {canEdit && (
            <Button onClick={() => setShowEdit(true)}>Редактировать</Button>
          )}
        </Space>
      )}

      {isInWork && canComplete && (
        <Form
          layout="vertical"
          form={form}
          onFinish={completeOrder}
          initialValues={{
            completedBy: me ? [{ value: me.id, label: me.fio }] : [],
          }}
        >
          <Form.Item name="note" label="Примечание">
            <Input.TextArea rows={2} />
          </Form.Item>
          <Form.Item
            name="completedBy"
            label="Кто завершил"
            rules={[{ required: true, message: "Укажите кто завершил" }]}
          >
            <Select
              mode="multiple"
              labelInValue
              placeholder="Начните вводить ФИО"
              showSearch
              filterOption={false}
              onSearch={(val) => {
                if (val.length >= 3) {
                  api
                    .get("/users", { params: { q: val } })
                    .then(({ data }) => setUserOptions(data))
                    .catch(() => setUserOptions([]));
                }
              }}
              options={userOptions.map((u) => ({
                label: u.fio,
                value: u.id,
              }))}
            />
          </Form.Item>
          <Form.Item label="Фото/документы">
            <Upload
              action={`/api/workorders/${order.id}/attachments`}
              multiple
              listType="picture"
              showUploadList={{ showRemoveIcon: false }}
              beforeUpload={beforeUpload}
              onChange={({ file }) => {
                if (file.status === "uploading") setUploading(true);
                if (file.status === "done") {
                  setUploading(false);
                  message.success(`${file.name} загружен`);
                }
                if (file.status === "error") {
                  setUploading(false);
                  message.error(`${file.name} не удалось загрузить`);
                }
              }}
            >
              <Button icon={<UploadOutlined />}>Прикрепить</Button>
            </Upload>
          </Form.Item>
          <Button
            type="primary"
            htmlType="submit"
            loading={completing || uploading}
          >
            Завершить
          </Button>
        </Form>
      )}

      {isDone && (
        <div style={{ marginTop: 16 }}>
          <b>Завершил:</b>{" "}
          {order.completedBy
            ?.map((rel) => rel.user?.fio)
            .filter(Boolean)
            .join(", ") || "—"}{" "}
          <br />
          <b>Примечание:</b> {order.note || "—"} <br />
          <b>Дата:</b>{" "}
          {order.completedAt
            ? new Date(order.completedAt).toLocaleString()
            : "—"}
        </div>
      )}

      {isDone && canReopen && (
        <Button danger onClick={reopenOrder} style={{ marginTop: 12 }}>
          Вернуть на доработку
        </Button>
      )}
    </Space>
  );

  // ===== Комментарии =====
  const commentsTab = (
    <Space direction="vertical" style={{ width: "100%" }}>
      {order.comments?.length > 0 ? (
        <ul>
          {order.comments.map((c) => (
            <li key={c.id}>
              <b>{c.author?.fio || "Неизвестный"}:</b> {c.text}{" "}
              <i>({new Date(c.createdAt).toLocaleString()})</i>
            </li>
          ))}
        </ul>
      ) : (
        <div style={{ color: "#888" }}>Нет комментариев</div>
      )}

      <Space style={{ width: "100%" }}>
        <Input.TextArea
          value={commentText}
          onChange={(e) => setCommentText(e.target.value)}
          rows={2}
          placeholder="Напишите комментарий..."
          onPressEnter={(e) => {
            if (!e.shiftKey) {
              e.preventDefault();
              addComment();
            }
          }}
        />
        <Button type="primary" onClick={addComment}>
          Отправить
        </Button>
      </Space>
    </Space>
  );

  return (
    <>
      <Modal
        open={!!orderId}
        onCancel={onClose}
        footer={null}
        title={`Заявка №${order.id}`}
        width={720}
      >
        <Tabs
          defaultActiveKey="main"
          items={[
            { key: "main", label: "Основное", children: mainTab },
            { key: "comments", label: "Комментарии", children: commentsTab },
          ]}
        />
      </Modal>

      <PassportModal
        open={!!showPassport}
        equipment={showPassport}
        onClose={() => setShowPassport(null)}
      />

      <CreateOrderModal
        open={showEdit}
        onClose={() => setShowEdit(false)}
        isEdit
        initialValues={order}
        onSaved={loadOrder}
      />
    </>
  );
}
