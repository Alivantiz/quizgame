// src/pages/Workorders/useOrders.js
import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import api from "../../api";
import { message } from "antd";

export function useOrders(me) {
  const [orders, setOrders] = useState([]);

  // 🔹 фильтрация по ролям
  const filterByRole = (items, user) => {
    if (!user) return items;

    const isAdmin = user.role === "admin";
    const isUchastok = user.role === "uchastok";
    const isSluzhba = user.role === "sluzhba";
    const isViewer = user.role === "viewer";

    if (isAdmin) return items;

    if (isUchastok && user.area?.id) {
      return items.filter((o) => o.area?.id === user.area.id);
    }

    if (isSluzhba && user.department?.id) {
      return items.filter((o) =>
        o.assignedTo?.some((d) => d.id === user.department.id)
      );
    }

    if (isViewer) {
      return items.filter((o) => o.issuedBy?.id === user.id);
    }

    return items;
  };

  // 🔹 начальная загрузка
  useEffect(() => {
    if (!me) return;
    api.get("/workorders")
      .then(({ data }) => {
        setOrders(filterByRole(data, me));
      })
      .catch(() => message.error("Ошибка загрузки заявок"));
  }, [me]);

  // 🔹 сокеты
  useEffect(() => {
    if (!me) return;

    const base = (import.meta.env.VITE_API_URL || "http://localhost:8080/api")
      .replace(/\/api\/?$/, "");
    const socket = io(base, { transports: ["websocket"], withCredentials: true });

    // подключаем пользователя в нужные комнаты
    if (me.role === "admin") socket.emit("joinAdmin");
    if (me.department?.id) socket.emit("joinDepartment", me.department.id);
    if (me.id) socket.emit("joinUser", me.id);

    // новая заявка
    socket.on("newWorkOrder", (order) => {
      if (filterByRole([order], me).length > 0) {
        message.info(`🔔 Новая заявка: ${order.objectName || order.issue}`);
        setOrders((prev) => [order, ...prev]);
      }
    });

    // изменение статуса (принятие, завершение, возврат)
    socket.on("statusChanged", (order) => {
      if (filterByRole([order], me).length > 0) {
        setOrders((prev) =>
          prev.map((o) => (o.id === order.id ? order : o))
        );
      }
    });

    // редактирование заявки
    socket.on("orderUpdated", (order) => {
      if (filterByRole([order], me).length > 0) {
        setOrders((prev) =>
          prev.map((o) => (o.id === order.id ? order : o))
        );
      }
    });

    // новый комментарий
    socket.on("commentAdded", ({ orderId, comment }) => {
      setOrders((prev) =>
        prev.map((o) =>
          o.id === orderId
            ? { ...o, comments: [...(o.comments || []), comment] }
            : o
        )
      );
    });

    // новое вложение
    socket.on("attachmentAdded", ({ orderId, attachment }) => {
      setOrders((prev) =>
        prev.map((o) =>
          o.id === orderId
            ? { ...o, attachments: [...(o.attachments || []), attachment] }
            : o
        )
      );
    });

    return () => socket.disconnect();
  }, [me]);

  return [orders, setOrders];
}
