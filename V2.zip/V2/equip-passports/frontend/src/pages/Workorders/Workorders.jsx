// src/pages/Workorders/Workorders.jsx
import { useEffect, useState, useMemo } from "react";
import {
  Card,
  Tabs,
  Tag,
  Table,
  Button,
  message,
  Space,
  Grid,
  Typography,
  Modal,
} from "antd";
import { STATUS_COLORS } from "./constants";
import CreateOrderModal from "./CreateOrderModal";
import OrderDetailModal from "./OrderDetailModal";
import PassportModal from "../Catalog/PassportModal.jsx";
import api from "../../api";
import { io } from "socket.io-client";
import { useUser } from "../../UserContext.jsx";
import Login from "../Login.jsx";
import "./Workorders.css";

export default function Workorders() {
  const { me } = useUser();

  const [allOrders, setAllOrders] = useState([]);
  const [filter, setFilter] = useState("all");
  const [createOpen, setCreateOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [current, setCurrent] = useState(null);
  const [showPassport, setShowPassport] = useState(null);
  const [highlightId, setHighlightId] = useState(null);

  const screens = Grid.useBreakpoint();
  const isMobile = !screens.md;

  const [showCompleted, setShowCompleted] = useState(() => {
    const saved = localStorage.getItem("showCompleted");
    return saved !== null ? JSON.parse(saved) : true;
  });
  useEffect(() => {
    localStorage.setItem("showCompleted", JSON.stringify(showCompleted));
  }, [showCompleted]);

  // 🔹 загрузка заявок
  const loadOrders = async () => {
    try {
      const { data } = await api.get("/workorders");
      setAllOrders(data);
    } catch {
      message.error("Ошибка загрузки заявок");
    }
  };

  useEffect(() => {
    loadOrders();

    const base = (import.meta.env.VITE_API_URL || "http://localhost:8080/api")
      .replace(/\/api\/?$/, "");
    const socket = io(base, { transports: ["websocket"], withCredentials: true });

    socket.on("newWorkOrder", (order) => {
      loadOrders();
      setHighlightId(order.id);
      setTimeout(() => setHighlightId(null), 5000);
    });

    socket.on("statusChanged", loadOrders);
    socket.on("orderUpdated", loadOrders);
    socket.on("commentAdded", loadOrders);
    socket.on("attachmentAdded", loadOrders);

    return () => socket.disconnect();
  }, []);

  const counts = useMemo(() => {
    const c = { all: allOrders.length, новая: 0, "в работе": 0, завершена: 0 };
    allOrders.forEach((o) => {
      c[o.status] = (c[o.status] || 0) + 1;
    });
    return c;
  }, [allOrders]);

  const orders = useMemo(() => {
    let list = allOrders;
    if (filter !== "all") list = list.filter((o) => o.status === filter);
    if (!showCompleted) list = list.filter((o) => o.status !== "завершена");
    return [...list].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }, [allOrders, filter, showCompleted]);

  const columns = [
    { title: "№", dataIndex: "id", width: 80 },
    {
      title: "Объект",
      render: (_, rec) => (
        <Button
          type="link"
          onClick={(e) => {
            e.stopPropagation();
            if (rec.equipment) setShowPassport(rec.equipment);
          }}
        >
          {rec.equipment
            ? `${rec.equipment.name} (${rec.equipment.position})`
            : rec.objectName}
        </Button>
      ),
    },
    { title: "Неисправность", dataIndex: "issue" },
    { title: "Цех", width: 120, render: (_, rec) => rec.area?.name },
    {
      title: "Выдал",
      width: 160,
      render: (_, rec) => rec.issuedBy?.fio || rec.issuedBy?.login,
    },
    {
      title: "Дата",
      dataIndex: "createdAt",
      width: 180,
      render: (d) => new Date(d).toLocaleString(),
    },
    {
      title: "Статус",
      dataIndex: "status",
      width: 240,
      render: (s, rec) => (
        <Space direction="vertical" size={0}>
          <Tag color={STATUS_COLORS[s]}>{s}</Tag>

          {/* 🔹 кто принял в работу */}
          {s.toLowerCase().includes("работ") && rec.acceptedBy && (
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              {`Принял: ${rec.acceptedBy.fio || rec.acceptedBy.login || "—"}`}
            </Typography.Text>
          )}

          {/* 🔹 кто завершил */}
          {s.toLowerCase().includes("заверш") && rec.completedBy?.length > 0 && (
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              {`Завершил: ${
                rec.completedBy
                  .map((rel) => rel.user?.fio || rel.user?.login)
                  .filter(Boolean)
                  .join(", ") || "—"
              } · ${
                rec.completedAt ? new Date(rec.completedAt).toLocaleString() : "—"
              }`}
            </Typography.Text>
          )}
        </Space>
      ),
    },
  ];

  return (
    <Card
      title="Заявки"
      extra={
        <Button
          type="primary"
          onClick={() => {
            if (me?.role === "guest") {
              setLoginOpen(true);
            } else {
              setCreateOpen(true);
            }
          }}
        >
          Создать
        </Button>
      }
    >
      <Tabs
        activeKey={filter}
        onChange={setFilter}
        items={[
          { key: "all", label: `Все (${counts.all})` },
          { key: "новая", label: `Новая (${counts["новая"] || 0})` },
          { key: "в работе", label: `В работе (${counts["в работе"] || 0})` },
          { key: "завершена", label: `Завершена (${counts["завершена"] || 0})` },
        ]}
      />

      {!isMobile && (
        <Table
          rowKey="id"
          columns={columns}
          dataSource={orders}
          pagination={{ pageSize: 10 }}
          rowClassName={(rec) => (rec.id === highlightId ? "highlight-row" : "")}
          onRow={(rec) => ({
            onClick: () => setCurrent(rec.id),
            style: { cursor: "pointer" },
          })}
          scroll={{ x: true }}
        />
      )}

      {isMobile && (
        <Space direction="vertical" style={{ width: "100%" }}>
          {orders.map((o) => (
            <Card
              key={o.id}
              size="small"
              hoverable
              onClick={() => setCurrent(o.id)}
              className={o.id === highlightId ? "highlight-row" : ""}
            >
              <Space direction="vertical" style={{ width: "100%" }}>
                <Typography.Text strong>Заявка №{o.id}</Typography.Text>
                <div style={{ fontSize: 13 }}>
                  <Button
                    type="link"
                    onClick={(e) => {
                      e.stopPropagation();
                      if (o.equipment) setShowPassport(o.equipment);
                    }}
                  >
                    {o.equipment
                      ? `${o.equipment.name} (${o.equipment.position})`
                      : o.objectName}
                  </Button>
                  {" · "}
                  {o.area?.name}
                </div>
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                  {o.issue}
                </Typography.Text>

                <Tag color={STATUS_COLORS[o.status]}>{o.status}</Tag>

                {/* 🔹 кто принял */}
                {o.status.toLowerCase().includes("работ") && o.acceptedBy && (
                  <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                    {`Принял: ${o.acceptedBy.fio || o.acceptedBy.login || "—"}`}
                  </Typography.Text>
                )}

                {/* 🔹 кто завершил */}
                {o.status.toLowerCase().includes("заверш") &&
                  o.completedBy?.length > 0 && (
                    <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                      {`Завершил: ${
                        o.completedBy
                          .map((rel) => rel.user?.fio || rel.user?.login)
                          .filter(Boolean)
                          .join(", ") || "—"
                      } · ${
                        o.completedAt
                          ? new Date(o.completedAt).toLocaleString()
                          : "—"
                      }`}
                    </Typography.Text>
                  )}
              </Space>
            </Card>
          ))}
        </Space>
      )}

      {/* модалка создания заявки */}
      {me?.role !== "guest" && (
        <CreateOrderModal
          open={createOpen}
          onClose={() => setCreateOpen(false)}
          onSaved={loadOrders}
        />
      )}

      <OrderDetailModal
        orderId={current}
        onClose={() => {
          setCurrent(null);
          loadOrders(); // обновляем список при закрытии
        }}
      />
      <PassportModal
        open={!!showPassport}
        equipment={showPassport}
        onClose={() => setShowPassport(null)}
        me={me}
      />

      {/* 🔹 модалка авторизации для гостя */}
      <Modal
        title="Авторизация по ID"
        open={loginOpen}
        onCancel={() => setLoginOpen(false)}
        footer={null}
        destroyOnClose
      >
        <Login
          onLogin={() => {
            setLoginOpen(false);
            setCreateOpen(true); // 👉 сразу открыть форму создания после входа
            loadOrders();
          }}
        />
      </Modal>
    </Card>
  );
}
