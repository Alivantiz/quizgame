// src/pages/Workorders/hooks/useOrderDetail.js
import { useEffect, useState, useCallback } from "react";
import api from "../../api";
import { message } from "antd";
import { io } from "socket.io-client";

export function useOrderDetail(orderId) {
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(false);

  // 🔹 загрузка заявки
  const loadOrder = useCallback(async () => {
    if (!orderId) {
      setOrder(null);
      return;
    }
    setLoading(true);
    try {
      const { data } = await api.get(`/workorders/${orderId}`);
      setOrder(data);
    } catch (e) {
      console.error("Ошибка загрузки заявки:", e);
      if (e.response?.status === 403) {
        message.warning("У вас нет доступа к этой заявке");
      } else {
        message.error("Ошибка загрузки заявки");
      }
    } finally {
      setLoading(false);
    }
  }, [orderId]);

  // 🔹 начальная загрузка
  useEffect(() => {
    loadOrder();
  }, [loadOrder]);

  // 🔹 сокеты
  useEffect(() => {
    if (!orderId) return;

    const base = (import.meta.env.VITE_API_URL || "http://localhost:8080/api")
      .replace(/\/api\/?$/, "");
    const socket = io(base, {
      transports: ["websocket"],
      withCredentials: true,
    });

    socket.on("commentAdded", (payload) => {
      if (payload.orderId === orderId) {
        setOrder((prev) => ({
          ...prev,
          comments: [...(prev?.comments || []), payload.comment],
        }));
      }
    });

    socket.on("attachmentAdded", (payload) => {
      if (payload.orderId === orderId) {
        setOrder((prev) => ({
          ...prev,
          attachments: [...(prev?.attachments || []), payload.attachment],
        }));
      }
    });

    socket.on("orderUpdated", (updated) => {
      if (updated.id === orderId) setOrder(updated);
    });

    socket.on("statusChanged", (updated) => {
      if (updated.id === orderId) setOrder(updated);
    });

    return () => socket.disconnect();
  }, [orderId]);

  return { order, setOrder, loadOrder, loading };
}
