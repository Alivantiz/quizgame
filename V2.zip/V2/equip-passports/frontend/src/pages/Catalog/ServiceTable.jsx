import { Table, message } from "antd";
import { useEffect, useState } from "react";
import api from "../../api"; // 👈 у тебя уже есть общий api

export default function ServiceTable({ equipmentId }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    if (!equipmentId) return;
    setLoading(true);
    try {
      // ⚡️ позже подключишь реальный эндпоинт
      // const { data } = await api.get(`/equipment/${equipmentId}/services`);
      // setRows(data);

      setRows([]); // пока пусто — заглушка
    } catch {
      message.error("Ошибка загрузки истории ТО/ремонтов");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [equipmentId]);

  return (
    <Table
      rowKey="id"
      dataSource={rows}
      loading={loading}
      pagination={false}
      locale={{ emptyText: "Нет данных по ТО/ремонтам" }}
      columns={[
        { title: "Дата", dataIndex: "date" },
        { title: "Вид работ", dataIndex: "type" },
        { title: "Исполнитель", dataIndex: "executor" },
        { title: "Комментарий", dataIndex: "note" },
      ]}
    />
  );
}
