import { Table, Tag, message } from "antd";
import { useEffect, useState } from "react";
import api from "../../api";
import { STATUS_COLORS } from "./constants";

export default function OrdersTable({ equipmentId }) {
  const [orders, setOrders] = useState([]);

  const load = async () => {
    if (!equipmentId) return;
    try {
      // ⚡️ теперь корректно грузим заявки по оборудованию
      const { data } = await api.get(`/equipment/${equipmentId}/orders`);
      setOrders(data);
    } catch {
      message.error("Ошибка загрузки заявок");
    }
  };

  useEffect(() => {
    load();
  }, [equipmentId]);

  return (
    <Table
      rowKey="id"
      dataSource={orders}
      pagination={false}
      columns={[
        { title: "№", dataIndex: "id", width: 70 },
        { title: "Неисправность", dataIndex: "issue" },
        {
          title: "Дата",
          dataIndex: "createdAt",
          render: (d) => new Date(d).toLocaleString(),
        },
        {
          title: "Статус",
          dataIndex: "status",
          render: (s) => (
            <Tag color={STATUS_COLORS[s] || "default"}>{s}</Tag>
          ),
        },
        {
          title: "Исполнитель",
          render: (_, rec) =>
            rec.completedBy?.fio ||
            rec.acceptedBy?.fio ||
            (rec.assignments?.map((a) => a.department?.name).join(", ") || "-"),
        },
      ]}
    />
  );
}
