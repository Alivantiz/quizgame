import { Table, Upload, Button, message } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import { useEffect, useState } from "react";
import api from "../../api";

export default function DocsTable({ equipmentId }) {
  const [docs, setDocs] = useState([]);

  const load = async () => {
    try {
      const { data } = await api.get(`/equipment/${equipmentId}/documents`);
      setDocs(data);
    } catch {
      message.error("Ошибка загрузки документов");
    }
  };

  useEffect(() => {
    if (equipmentId) load();
  }, [equipmentId]);

  return (
    <>
      <Upload
        action={`/api/equipment/${equipmentId}/documents`}
        multiple
        showUploadList={false}
        onChange={({ file }) => {
          if (file.status === "done") {
            message.success(`${file.name} загружен`);
            load();
          }
          if (file.status === "error") {
            message.error(`${file.name} ошибка загрузки`);
          }
        }}
      >
        <Button icon={<UploadOutlined />}>Загрузить документ</Button>
      </Upload>

      <Table
        rowKey="id"
        dataSource={docs}
        pagination={false}
        style={{ marginTop: 16 }}
        columns={[
          { title: "Файл", dataIndex: "name" }, // ⚡️ у тебя в бэке поле `name`
          {
            title: "Действия",
            render: (_, rec) => (
              <a href={rec.url} target="_blank" rel="noreferrer">
                Открыть
              </a>
            ),
          },
        ]}
      />
    </>
  );
}
