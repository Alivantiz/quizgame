export const STATUS_COLORS = {
  работает: "green",
  "план ТО": "gold",
  авария: "red",
  "в резерве": "default"
};

export const AREAS = ["ГТП", "ЦППР", "АЦ", "ТНС"];
