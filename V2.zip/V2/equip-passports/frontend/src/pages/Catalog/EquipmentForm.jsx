// src/pages/Catalog/EquipmentForm.jsx
import { useEffect, useState } from "react";
import { Modal, Form, Input, Select, Button, message } from "antd";
import { STATUS_COLORS } from "./constants";
import api from "../../api";

// маппинг для статусов
const STATUS_MAP = {
  работает: "RABOTAET",
  "план ТО": "PLAN_TO",
  авария: "AVARIYA",
  "в резерве": "V_REZERVE",
};

export default function EquipmentForm({ open, onClose, reload, editItem }) {
  const [form] = Form.useForm();
  const [areas, setAreas] = useState([]);

  // загрузка списка цехов
  useEffect(() => {
    if (!open) return;
    api
      .get("/areas")
      .then(({ data }) => setAreas(data))
      .catch(() => message.error("Ошибка загрузки цехов"));

    // если редактируем → заполняем форму
    if (editItem) {
      form.setFieldsValue({
        ...editItem,
        areaId: editItem.area?.id,
        status: editItem.status,
      });
    } else {
      form.resetFields();
    }
  }, [open, editItem]);

  const onSubmit = async (v) => {
    try {
      const payload = {
        category: v.category,
        position: v.position,
        name: v.name,
        serial: v.serial,
        areaId: Number(v.areaId),
        status: STATUS_MAP[v.status] || "RABOTAET",
      };

      if (editItem) {
        await api.put(`/equipment/${editItem.id}`, payload);
        message.success("Оборудование обновлено");
      } else {
        await api.post("/equipment", payload);
        message.success("Оборудование добавлено");
      }

      onClose();
      form.resetFields();
      if (reload) reload();
    } catch {
      message.error("Ошибка при сохранении (проверьте уникальность серийного)");
    }
  };

  return (
    <Modal
      title={editItem ? "Редактировать оборудование" : "Новое оборудование"}
      open={open}
      onCancel={onClose}
      footer={null}
      destroyOnClose
    >
      <Form layout="vertical" form={form} onFinish={onSubmit}>
        <Form.Item name="category" label="Категория" rules={[{ required: true }]}>
          <Input />
        </Form.Item>

        <Form.Item name="position" label="Позиция" rules={[{ required: true }]}>
          <Input />
        </Form.Item>

        <Form.Item name="name" label="Название" rules={[{ required: true }]}>
          <Input />
        </Form.Item>

        <Form.Item name="serial" label="Серийный" rules={[{ required: true }]}>
          <Input />
        </Form.Item>

        <Form.Item name="areaId" label="Цех" rules={[{ required: true }]}>
          <Select
            placeholder="Выберите цех"
            options={areas.map((a) => ({ label: a.name, value: a.id }))}
          />
        </Form.Item>

        <Form.Item name="status" label="Статус" initialValue="работает">
          <Select
            options={Object.keys(STATUS_COLORS).map((s) => ({
              label: s,
              value: s,
            }))}
          />
        </Form.Item>

        <Button type="primary" htmlType="submit" block>
          Сохранить
        </Button>
      </Form>
    </Modal>
  );
}
