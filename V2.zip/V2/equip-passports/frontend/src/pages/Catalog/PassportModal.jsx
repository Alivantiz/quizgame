import { useEffect, useState } from "react";
import {
  Modal,
  Tabs,
  Tag,
  Table,
  Button,
  message,
  Form,
  Input,
  Space,
  Popconfirm,
  Upload,
} from "antd";
import {
  FileOutlined,
  PlusOutlined,
  DeleteOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import api from "../../api";
import { STATUS_COLORS } from "./constants";
import CreateOrderModal from "../Workorders/CreateOrderModal.jsx";

export default function PassportModal({ open, equipment, onClose, me }) {
  const [attrs, setAttrs] = useState([]);
  const [docs, setDocs] = useState([]);
  const [orders, setOrders] = useState([]);
  const [eqFull, setEqFull] = useState(null);
  const [attrForm] = Form.useForm();
  const [createOpen, setCreateOpen] = useState(false);

  const role = me?.role?.toLowerCase();
  const isAdmin = role === "admin";
  const isUchastok = role === "uchastok";
  const canEdit = isAdmin || isUchastok;

  // 🔹 загрузка оборудования и связанных данных
  const loadAll = async () => {
    if (!equipment?.id) return;
    try {
      const [eqRes, attrRes, docRes, ordRes] = await Promise.all([
        api.get(`/equipment/${equipment.id}`),
        api.get(`/equipment/${equipment.id}/attributes`),
        api.get(`/equipment/${equipment.id}/documents`),
        api.get(`/equipment/${equipment.id}/orders`),
      ]);
      setEqFull(eqRes.data);
      setAttrs(attrRes.data);
      setDocs(docRes.data);
      setOrders(ordRes.data);
    } catch {
      message.error("Ошибка загрузки паспорта оборудования");
    }
  };

  useEffect(() => {
    if (open) loadAll();
  }, [open, equipment?.id]);

  if (!eqFull) return null;

  const mainData = [
    { key: "Категория", value: eqFull.category },
    { key: "Серийный №", value: eqFull.serial },
    { key: "Позиция", value: eqFull.position },
    { key: "Цех", value: eqFull.area?.name || "-" },
    {
      key: "Статус",
      value: <Tag color={STATUS_COLORS[eqFull.status]}>{eqFull.status}</Tag>,
    },
    { key: "Создано", value: new Date(eqFull.createdAt).toLocaleString() },
  ];

  // 🔹 добавить характеристику
  const addAttr = async (v) => {
    try {
      const { data } = await api.post(`/equipment/${eqFull.id}/attributes`, v);
      setAttrs((prev) => [...prev, data]);
      message.success("Характеристика добавлена");
      attrForm.resetFields();
    } catch {
      message.error("Ошибка при добавлении характеристики");
    }
  };

  // 🔹 удалить характеристику
  const delAttr = async (id) => {
    try {
      await api.delete(`/equipment/attributes/${id}`);
      setAttrs((prev) => prev.filter((a) => a.id !== id));
      message.success("Удалено");
    } catch {
      message.error("Ошибка удаления");
    }
  };

  // 🔹 удалить документ
  const delDoc = async (id) => {
    try {
      await api.delete(`/equipment/documents/${id}`);
      setDocs((prev) => prev.filter((d) => d.id !== id));
      message.success("Документ удалён");
    } catch {
      message.error("Ошибка удаления документа");
    }
  };

  return (
    <>
      <Modal
        open={open}
        onCancel={onClose}
        footer={null}
        title={`Паспорт: ${eqFull.name}`}
        width={900}
      >
        <Tabs
          defaultActiveKey="main"
          items={[
            {
              key: "main",
              label: "Основное",
              children: (
                <Table
                  showHeader={false}
                  pagination={false}
                  rowKey="key"
                  dataSource={mainData}
                  columns={[
                    { dataIndex: "key", width: 200 },
                    { dataIndex: "value" },
                  ]}
                />
              ),
            },
            {
              key: "attrs",
              label: "Характеристики",
              children: (
                <>
                  <Table
                    rowKey="id"
                    dataSource={attrs}
                    pagination={false}
                    columns={[
                      { title: "Ключ", dataIndex: "key" },
                      { title: "Значение", dataIndex: "value" },
                      ...(canEdit
                        ? [
                            {
                              title: "Действия",
                              render: (_, rec) => (
                                <Popconfirm
                                  title="Удалить характеристику?"
                                  onConfirm={() => delAttr(rec.id)}
                                >
                                  <Button
                                    size="small"
                                    danger
                                    icon={<DeleteOutlined />}
                                  >
                                    Удалить
                                  </Button>
                                </Popconfirm>
                              ),
                            },
                          ]
                        : []),
                    ]}
                  />
                  {canEdit && (
                    <Form
                      form={attrForm}
                      layout="inline"
                      onFinish={addAttr}
                      style={{ marginTop: 12 }}
                    >
                      <Form.Item
                        name="key"
                        rules={[{ required: true, message: "Введите параметр" }]}
                      >
                        <Input placeholder="Ключ" />
                      </Form.Item>
                      <Form.Item name="value">
                        <Input placeholder="Значение" />
                      </Form.Item>
                      <Form.Item>
                        <Button
                          type="primary"
                          htmlType="submit"
                          icon={<PlusOutlined />}
                        >
                          Добавить
                        </Button>
                      </Form.Item>
                    </Form>
                  )}
                </>
              ),
            },
            {
              key: "docs",
              label: "Документы",
              children: (
                <>
                  <Table
                    rowKey="id"
                    dataSource={docs}
                    pagination={false}
                    columns={[
                      { title: "Название", dataIndex: "name" },
                      {
                        title: "Файл",
                        dataIndex: "url",
                        render: (url) => (
                          <Button
                            type="link"
                            href={url}
                            target="_blank"
                            icon={<FileOutlined />}
                          >
                            Скачать
                          </Button>
                        ),
                      },
                      ...(canEdit
                        ? [
                            {
                              title: "Действия",
                              render: (_, rec) => (
                                <Popconfirm
                                  title="Удалить документ?"
                                  onConfirm={() => delDoc(rec.id)}
                                >
                                  <Button
                                    size="small"
                                    danger
                                    icon={<DeleteOutlined />}
                                  >
                                    Удалить
                                  </Button>
                                </Popconfirm>
                              ),
                            },
                          ]
                        : []),
                    ]}
                  />

                  {canEdit && (
                    <Upload
                      action={`/api/equipment/${eqFull.id}/documents`}
                      multiple
                      showUploadList={false}
                      onChange={({ file }) => {
                        if (file.status === "done") {
                          message.success(`${file.name} загружен`);
                          loadAll();
                        }
                        if (file.status === "error") {
                          message.error(`${file.name} ошибка загрузки`);
                        }
                      }}
                    >
                      <Button
                        type="primary"
                        icon={<UploadOutlined />}
                        style={{ marginTop: 12 }}
                      >
                        Загрузить документ
                      </Button>
                    </Upload>
                  )}
                </>
              ),
            },
            {
              key: "orders",
              label: "Заявки",
              children: (
                <>
                  <Table
                    rowKey="id"
                    dataSource={orders}
                    pagination={false}
                    columns={[
                      { title: "№", dataIndex: "id", width: 70 },
                      { title: "Неисправность", dataIndex: "issue" },
                      {
                        title: "Статус",
                        dataIndex: "status",
                        render: (s) => (
                          <Tag color={STATUS_COLORS[s]}>{s}</Tag>
                        ),
                      },
                      {
                        title: "Создана",
                        dataIndex: "createdAt",
                        render: (d) => new Date(d).toLocaleString(),
                      },
                      {
                        title: "Исполнитель",
                        render: (_, rec) =>
                          rec.completedBy?.fio ||
                          rec.acceptedBy?.fio ||
                          (rec.assignments
                            ?.map((a) => a.department?.name)
                            .join(", ") || "-"),
                      },
                    ]}
                  />
                  {canEdit && (
                    <div style={{ marginTop: 12 }}>
                      <Button
                        type="primary"
                        onClick={() => setCreateOpen(true)}
                      >
                        Создать заявку по этому оборудованию
                      </Button>
                    </div>
                  )}
                </>
              ),
            },
            {
              key: "repairs",
              label: "ТО/ремонты",
              children: <div>🔧 Здесь можно вывести историю ТО и ремонтов</div>,
            },
          ]}
        />
      </Modal>

      {/* 🔹 Модалка создания заявки */}
      {canEdit && (
        <CreateOrderModal
          open={createOpen}
          onClose={() => setCreateOpen(false)}
          me={me}
          initialValues={{
            equipmentId: eqFull?.id,
            area: eqFull?.area,
          }}
          onSaved={loadAll}
        />
      )}
    </>
  );
}
