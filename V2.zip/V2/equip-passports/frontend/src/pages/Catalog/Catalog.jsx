import { useEffect, useMemo, useState } from "react";
import {
  Card,
  Table,
  Tag,
  Button,
  Modal,
  Form,
  Input,
  Select,
  Space,
  message,
  Grid,
  Typography,
} from "antd";
import {
  QrcodeOutlined,
  EditOutlined,
  DownloadOutlined,
  DeleteOutlined,
  PlusOutlined,
  ApartmentOutlined,
} from "@ant-design/icons";
import QRCode from "react-qr-code";
import api from "../../api";
import { useSearchParams } from "react-router-dom";
import PassportModal from "./PassportModal.jsx";
import { STATUS_COLORS } from "./constants";
import { useUser } from "../../UserContext.jsx";
import Login from "../Login.jsx";

export default function Catalog() {
  const { me } = useUser();

  const [list, setList] = useState([]);
  const [areas, setAreas] = useState([]);
  const [statusFilter, setStatusFilter] = useState();
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form] = Form.useForm();
  const [selected, setSelected] = useState(null);
  const [qrEquipment, setQrEquipment] = useState(null);
  const [editItem, setEditItem] = useState(null);

  // управление цехами
  const [areaModal, setAreaModal] = useState(false);
  const [editArea, setEditArea] = useState(null);
  const [areaForm] = Form.useForm();

  // авторизация для гостя
  const [loginOpen, setLoginOpen] = useState(false);

  const role = me?.role?.toLowerCase?.();
  const isAdmin = role === "admin";
  const isUchastok = role === "uchastok";

  const [searchParams] = useSearchParams();
  const screens = Grid.useBreakpoint();
  const isMobile = !screens.md;

  // загрузка оборудования
  const load = async () => {
    try {
      const { data } = await api.get("/equipment");
      setList(data);
    } catch {
      message.error("Ошибка загрузки оборудования");
    }
  };

  // загрузка цехов
  const loadAreas = async () => {
    try {
      const { data } = await api.get("/areas");
      setAreas(data);
    } catch {
      message.error("Ошибка загрузки списка цехов");
    }
  };

  useEffect(() => {
    if (me === undefined) return;
    load();
    loadAreas();
  }, [me?.id, me?.role, me?.areaId]);

  // удалить оборудование
  const removeEquipment = (item) => {
    Modal.confirm({
      title: "Удалить оборудование?",
      content: (
        <Typography.Text type="danger">
          Удалить <b>{item.name}</b>? <br />
          Также удалятся его заявки, атрибуты и документы!
        </Typography.Text>
      ),
      okText: "Удалить",
      cancelText: "Отмена",
      okButtonProps: { danger: true },
      async onOk() {
        try {
          await api.delete(`/equipment/${item.id}`);
          message.success("Оборудование удалено");
          load();
        } catch {
          message.error("Ошибка удаления");
        }
      },
    });
  };

  // сохранить цех
  const saveArea = async (v) => {
    try {
      if (editArea) {
        await api.put(`/areas/${editArea.id}`, v);
        message.success("Цех обновлён");
      } else {
        await api.post("/areas", v);
        message.success("Цех добавлен");
      }
      setEditArea(null);
      areaForm.resetFields();
      loadAreas();
    } catch {
      message.error("Ошибка сохранения цеха (возможно, дублирование)");
    }
  };

  // удалить цех
  const removeArea = (area) => {
    Modal.confirm({
      title: "Удалить цех?",
      content: (
        <Typography.Text type="danger">
          Цех <b>{area.name}</b> будет удалён вместе со всем оборудованием!
        </Typography.Text>
      ),
      okText: "Удалить",
      cancelText: "Отмена",
      okButtonProps: { danger: true },
      async onOk() {
        try {
          await api.delete(`/areas/${area.id}`);
          message.success("Цех удалён");
          loadAreas();
          load();
        } catch {
          message.error("Ошибка удаления цеха");
        }
      },
    });
  };

  // колонки таблицы
  const columns = [
    { title: "Оборудование", dataIndex: "name", sorter: (a, b) => a.name.localeCompare(b.name) },
    { title: "Категория", dataIndex: "category" },
    { title: "Позиция", dataIndex: "position" },
    { title: "Серийный", dataIndex: "serial" },
    { title: "Цех", render: (_, rec) => rec.area?.name || "-" },
    { title: "Статус", dataIndex: "status", render: (s) => <Tag color={STATUS_COLORS[s]}>{s}</Tag> },
    {
      title: "Действия",
      render: (_, rec) => (
        <Space>
          <Button
            icon={<QrcodeOutlined />}
            size="small"
            onClick={(e) => {
              e.stopPropagation();
              setQrEquipment(rec);
            }}
          >
            QR
          </Button>
          {me?.role !== "guest" && (
            <>
              <Button
                icon={<EditOutlined />}
                size="small"
                onClick={(e) => {
                  e.stopPropagation();
                  setEditItem(rec);
                  if (isUchastok && me?.areaId) {
                    form.setFieldsValue({ ...rec, areaId: me.areaId });
                  } else {
                    form.setFieldsValue(rec);
                  }
                  setOpen(true);
                }}
              >
                Редактировать
              </Button>
              {(isAdmin || isUchastok) && (
                <Button
                  danger
                  icon={<DeleteOutlined />}
                  size="small"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeEquipment(rec);
                  }}
                >
                  Удалить
                </Button>
              )}
            </>
          )}
        </Space>
      ),
    },
  ];

  // фильтрация
  const filtered = useMemo(() => {
    let arr = statusFilter ? list.filter((i) => i.status === statusFilter) : list;
    if (search) {
      const q = search.toLowerCase();
      arr = arr.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          (i.position || "").toLowerCase().includes(q) ||
          (i.serial || "").toLowerCase().includes(q)
      );
    }
    return arr;
  }, [list, statusFilter, search]);

  // добавление/редактирование
  const onSubmit = async (v) => {
    try {
      let payload = v;
      if (isUchastok && me?.areaId) {
        payload = { ...v, areaId: me.areaId };
      }
      if (editItem) {
        await api.put(`/equipment/${editItem.id}`, payload);
        message.success("Оборудование обновлено");
      } else {
        await api.post("/equipment", payload);
        message.success("Оборудование добавлено");
      }
      setOpen(false);
      setEditItem(null);
      form.resetFields();
      load();
    } catch {
      message.error("Ошибка сохранения (проверьте уникальность серийного)");
    }
  };

  // открыть паспорт по query
  useEffect(() => {
    const id = searchParams.get("id");
    if (id) {
      const item = list.find((i) => i.id === Number(id));
      if (item) setSelected(item);
    }
  }, [searchParams, list]);

  // скачать QR
  const downloadQR = () => {
    const svg = document.querySelector("#qr-download svg");
    if (!svg) return;
    const serializer = new XMLSerializer();
    const source = serializer.serializeToString(svg);
    const blob = new Blob([source], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${qrEquipment.name}_QR.svg`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (me === undefined) return null;

  return (
    <Card
      title="Каталог"
      extra={
        <Space>
          <Button
            type="primary"
            onClick={() => {
              if (me?.role === "guest") {
                setLoginOpen(true);
              } else {
                setOpen(true);
                setEditItem(null);
                if (isUchastok && me?.areaId) {
                  form.setFieldsValue({ areaId: me.areaId });
                } else {
                  form.resetFields();
                }
              }
            }}
            icon={<PlusOutlined />}
          >
            Добавить оборудование
          </Button>

          {isAdmin && (
            <Button onClick={() => setAreaModal(true)} icon={<ApartmentOutlined />}>
              Цеха
            </Button>
          )}
        </Space>
      }
    >
      {/* поиск/фильтры */}
      <Space style={{ marginBottom: 12, flexWrap: "wrap" }}>
        <Input.Search
          placeholder="Поиск по оборудованию"
          allowClear
          style={{ width: 260 }}
          onChange={(e) => setSearch(e.target.value)}
        />
        <Select
          placeholder="Фильтр по статусу"
          allowClear
          style={{ width: 220 }}
          value={statusFilter}
          onChange={setStatusFilter}
          options={Object.keys(STATUS_COLORS).map((s) => ({ label: s, value: s }))}
        />
      </Space>

      {/* таблица (ПК) */}
      {!isMobile && (
        <Table
          rowKey="id"
          columns={columns}
          dataSource={filtered}
          pagination={{ pageSize: 10 }}
          scroll={{ x: true }}
          onRow={(rec) => ({
            onClick: () => setSelected(rec),
            style: { cursor: "pointer" },
          })}
        />
      )}

      {/* карточки (мобилка) */}
      {isMobile && (
        <Space direction="vertical" style={{ width: "100%" }}>
          {filtered.map((item) => (
            <Card
              key={item.id}
              size="small"
              hoverable
              onClick={() => setSelected(item)}
              style={{ cursor: "pointer" }}
            >
              <Space direction="vertical" style={{ width: "100%" }}>
                <Typography.Text strong>{item.name}</Typography.Text>
                <div style={{ fontSize: 12, color: "#888" }}>
                  {item.category} · {item.area?.name}
                </div>
                <Tag color={STATUS_COLORS[item.status]}>{item.status}</Tag>
              </Space>
            </Card>
          ))}
        </Space>
      )}

      {/* модалка добавления/редактирования */}
      {me?.role !== "guest" && (
        <Modal
          title={editItem ? "Редактировать оборудование" : "Новое оборудование"}
          open={open}
          onCancel={() => {
            setOpen(false);
            setEditItem(null);
          }}
          footer={null}
          destroyOnClose
        >
          <Form
            layout="vertical"
            form={form}
            onFinish={onSubmit}
            initialValues={editItem || { status: Object.keys(STATUS_COLORS)[0] }}
          >
            <Form.Item name="category" label="Категория" rules={[{ required: true }]}>
              <Input />
            </Form.Item>
            <Form.Item name="position" label="Позиция" rules={[{ required: true }]}>
              <Input />
            </Form.Item>
            <Form.Item name="name" label="Название" rules={[{ required: true }]}>
              <Input />
            </Form.Item>
            <Form.Item name="serial" label="Серийный" rules={[{ required: true }]}>
              <Input />
            </Form.Item>
            <Form.Item name="areaId" label="Цех" rules={[{ required: true }]}>
              <Select
                options={areas.map((a) => ({ label: a.name, value: a.id }))}
                disabled={isUchastok}
              />
            </Form.Item>
            <Form.Item name="status" label="Статус">
              <Select options={Object.keys(STATUS_COLORS).map((s) => ({ label: s, value: s }))} />
            </Form.Item>
            <Button type="primary" htmlType="submit" block>
              Сохранить
            </Button>
          </Form>
        </Modal>
      )}

      {/* модалка управления цехами */}
      {isAdmin && (
        <Modal
          title="Управление цехами"
          open={areaModal}
          onCancel={() => {
            setAreaModal(false);
            setEditArea(null);
          }}
          footer={null}
        >
          <Table
            rowKey="id"
            size="small"
            dataSource={areas}
            columns={[
              { title: "Цех", dataIndex: "name" },
              {
                title: "Действия",
                render: (_, rec) => (
                  <Space>
                    <Button
                      size="small"
                      icon={<EditOutlined />}
                      onClick={() => {
                        setEditArea(rec);
                        areaForm.setFieldsValue(rec);
                      }}
                    />
                    <Button size="small" danger icon={<DeleteOutlined />} onClick={() => removeArea(rec)} />
                  </Space>
                ),
              },
            ]}
            pagination={false}
          />

          <Form form={areaForm} layout="inline" style={{ marginTop: 12 }} onFinish={saveArea}>
            <Form.Item name="name" rules={[{ required: true, message: "Введите название" }]}>
              <Input placeholder="Название цеха" />
            </Form.Item>
            <Button type="primary" htmlType="submit">
              {editArea ? "Сохранить" : "Добавить"}
            </Button>
          </Form>
        </Modal>
      )}

      {/* паспорт */}
      <PassportModal open={!!selected} equipment={selected} onClose={() => setSelected(null)} me={me} />

      {/* QR */}
      <Modal
        open={!!qrEquipment}
        onCancel={() => setQrEquipment(null)}
        footer={
          !isMobile && (
            <Button type="primary" icon={<DownloadOutlined />} onClick={downloadQR}>
              Скачать QR
            </Button>
          )
        }
        centered
      >
        {qrEquipment && (
          <Space id="qr-download" direction="vertical" style={{ width: "100%", textAlign: "center" }}>
            <Typography.Text strong>QR для: {qrEquipment.name}</Typography.Text>
            <QRCode
              value={`${window.location.origin}/catalog?id=${qrEquipment.id}`}
              size={256}
              includeMargin
              style={{ display: "block", margin: "0 auto" }}
            />
            <Typography.Text type="secondary">
              Наведите камеру или кликните для перехода
            </Typography.Text>
          </Space>
        )}
      </Modal>

      {/* модалка авторизации для гостя */}
      <Modal
        title="Авторизация по ID"
        open={loginOpen}
        onCancel={() => setLoginOpen(false)}
        footer={null}
        destroyOnClose
      >
        <Login
          onLogin={() => {
            setLoginOpen(false);
            setOpen(true); // 👉 сразу открываем форму добавления после входа
            load();
          }}
        />
      </Modal>
    </Card>
  );
}
