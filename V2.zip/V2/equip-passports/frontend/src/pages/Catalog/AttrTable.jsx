import { Table, Button, Form, Input, Popconfirm, message } from "antd";
import { useEffect, useState } from "react";
import api from "../../api";
import { useUser } from "../../UserContext.jsx";

export default function AttrTable({ equipmentId }) {
  const me = useUser();
  const [attrs, setAttrs] = useState([]);
  const [form] = Form.useForm();

  const load = async () => {
    try {
      const { data } = await api.get(`/equipment/${equipmentId}/attributes`);
      setAttrs(data);
    } catch {
      message.error("Ошибка загрузки характеристик");
    }
  };

  useEffect(() => {
    if (equipmentId) load();
  }, [equipmentId]);

  const addAttr = async (v) => {
    try {
      await api.post(`/equipment/${equipmentId}/attributes`, v);
      message.success("Характеристика добавлена");
      form.resetFields();
      load();
    } catch {
      message.error("Ошибка при добавлении");
    }
  };

  const delAttr = async (id) => {
    try {
      await api.delete(`/equipment/attributes/${id}`);
      message.success("Удалено");
      load();
    } catch {
      message.error("Ошибка удаления");
    }
  };

  const canEdit = me?.role === "admin" || me?.role === "uchastok";

  return (
    <>
      <Table
        rowKey="id"
        dataSource={attrs}
        pagination={false}
        columns={[
          { title: "Ключ", dataIndex: "key" },
          { title: "Значение", dataIndex: "value" },
          ...(canEdit
            ? [
                {
                  title: "Действия",
                  render: (_, rec) => (
                    <Popconfirm title="Удалить?" onConfirm={() => delAttr(rec.id)}>
                      <Button danger size="small">Удалить</Button>
                    </Popconfirm>
                  ),
                },
              ]
            : []),
        ]}
      />

      {canEdit && (
        <Form
          form={form}
          layout="inline"
          onFinish={addAttr}
          style={{ marginTop: 16 }}
        >
          <Form.Item name="key" rules={[{ required: true }]}>
            <Input placeholder="Параметр" />
          </Form.Item>
          <Form.Item name="value">
            <Input placeholder="Значение" />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">Добавить</Button>
          </Form.Item>
        </Form>
      )}
    </>
  );
}
