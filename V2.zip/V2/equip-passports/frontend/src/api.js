// src/api.js
import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8080/api",
  withCredentials: true, // всегда шлём httpOnly куки
});

// ===== Храним последний access-токен =====
let lastAccess = null;
export function getLastAccess() {
  return lastAccess;
}

// ===== Request Interceptor =====
// Если есть lastAccess, подставляем в заголовки Authorization
api.interceptors.request.use(
  (config) => {
    if (lastAccess) {
      config.headers = config.headers || {};
      config.headers.Authorization = `Bearer ${lastAccess}`;
    }
    return config;
  },
  (err) => Promise.reject(err)
);

// ===== Response Interceptor =====
// Если backend вернул { access }, обновляем lastAccess
api.interceptors.response.use(
  (res) => {
    if (res?.data?.access) {
      lastAccess = res.data.access;
    }
    return res;
  },
  async (err) => {
    const { response, config } = err || {};
    const status = response?.status;

    // 401 → пробуем обновить access
    if (status === 401 && config && !config.__retry) {
      config.__retry = true;
      try {
        const r = await api.post("/auth/refresh");
        if (r?.data?.access) {
          lastAccess = r.data.access;
        }
        return api(config); // повторим запрос с новым токеном
      } catch (e) {
        lastAccess = null;
        throw e;
      }
    }

    throw err;
  }
);

export default api;
